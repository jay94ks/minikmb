export default {
  isoName: 'zh-TW',
  nativeName: '中文（繁體）',
  label: {
    clear: '清除',
    ok: '確定',
    cancel: '取消',
    close: '關閉',
    set: '設定',
    select: '選擇',
    reset: '重置',
    remove: '移除',
    update: '更新',
    create: '新增',
    search: '搜尋',
    filter: '篩選',
    refresh: '更新',
    minimum: '最小值',
    maximum: '最大值',
    range: '範圍',
    noValue: '無值',
    resize: '調整大小',
    expand: label => (label ? `展開"${label}"` : '擴張'),
    collapse: label => (label ? `折疊"${label}"` : '坍塌')
  },
  date: {
    days: '星期日_星期一_星期二_星期三_星期四_星期五_星期六'.split('_'),
    daysShort: '週日_週一_週二_週三_週四_週五_週六'.split('_'),
    months:
      '一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月'.split(
        '_'
      ),
    monthsShort:
      '一月_二月_三月_四月_五月_六月_七月_八月_九月_十月_十一月_十二月'.split(
        '_'
      ),
    headerTitle: date =>
      new Intl.DateTimeFormat('zh-TW', {
        weekday: 'short',
        month: 'short',
        day: 'numeric'
      }).format(date),
    firstDayOfWeek: 0, // 0-6, 0 - Sunday, 1 Monday, ...
    format24h: false,
    pluralDay: '日',
    prevMonth: '上個月',
    nextMonth: '下個月',
    prevYear: '上一年',
    nextYear: '下一年',
    today: '今天',
    prevRangeYears: range => `前${range}年`,
    nextRangeYears: range => `後${range}年`,
    hour: '小時',
    minute: '分鐘',
    second: '秒',
    now: '目前時間'
  },
  table: {
    noData: '沒有資料',
    noResults: '沒有相符資料',
    loading: '載入中...',
    selectedRecords: rows => '已選擇 ' + rows + ' 列',
    recordsPerPage: '每頁列數：',
    allRows: '全部',
    pagination: (start, end, total) =>
      start + '〜' + end + ' 列，共 ' + total + ' 列',
    columns: '欄位',
    selectAllRows: '選擇所有列',
    selectRow: '選擇列'
  },
  pagination: {
    label: '分頁',
    first: '首頁',
    prev: '上一頁',
    next: '下一頁',
    last: '最後一頁'
  },
  carousel: {
    prevSlide: '上一張投影片',
    nextSlide: '下一張投影片'
  },
  colorPicker: {
    spectrum: '光譜',
    tune: '調整',
    palette: '調色盤',
    value: '顏色值',
    hue: '色相',
    alpha: '不透明度',
    saturation: '飽和度',
    brightness: '亮度'
  },
  uploader: {
    addFiles: '選擇檔案',
    upload: '上傳檔案',
    abort: '中止上傳',
    removeQueued: '移除佇列中的檔案',
    removeUploaded: '移除已上傳的檔案',
    removeFile: '移除檔案'
  },
  editor: {
    toolbar: '編輯器工具列',
    url: '網址',
    bold: '粗體',
    italic: '斜體',
    strikethrough: '刪除線',
    underline: '下劃線',
    unorderedList: '項目符號清單',
    orderedList: '編號清單',
    subscript: '下標',
    superscript: '上標',
    hyperlink: '超連結',
    toggleFullscreen: '切換全螢幕',
    quote: '段落引用',
    left: '靠左對齊',
    center: '置中對齊',
    right: '靠右對齊',
    justify: '分散對齊',
    print: '列印',
    outdent: '減少縮排',
    indent: '增加縮排',
    removeFormat: '清除格式',
    formatting: '區塊元素',
    fontSize: '字型大小',
    align: '對齊',
    hr: '水平分隔線',
    undo: '復原',
    redo: '取消復原',
    heading1: '標題 1',
    heading2: '標題 2',
    heading3: '標題 3',
    heading4: '標題 4',
    heading5: '標題 5',
    heading6: '標題 6',
    paragraph: '段落',
    code: '程式碼',
    size1: '非常小',
    size2: '稍小',
    size3: '正常',
    size4: '稍大',
    size5: '大',
    size6: '非常大',
    size7: '超級大',
    defaultFont: '預設字型',
    viewSource: '切換原始碼'
  },
  tree: {
    noNodes: '沒有節點',
    noResults: '沒有相符節點'
  }
}
