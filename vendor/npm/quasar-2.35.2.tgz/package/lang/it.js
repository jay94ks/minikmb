export default {
  isoName: 'it',
  nativeName: 'Italiano',
  label: {
    clear: 'Pulisci',
    ok: 'OK',
    cancel: 'Annulla',
    close: 'Chiudi',
    set: 'Imposta',
    select: 'Seleziona',
    reset: 'Ripristina',
    remove: 'Rimuovi',
    update: 'Aggiorna',
    create: 'Crea',
    search: 'Cerca',
    filter: 'Filtra',
    refresh: 'Aggiorna',
    minimum: 'Minimo',
    maximum: 'Massimo',
    range: 'Intervallo',
    noValue: 'Nessun valore',
    resize: 'Ridimensiona',
    expand: label => (label ? `Espandi "${label}"` : 'Espandere'),
    collapse: label => (label ? `Comprimi "${label}"` : 'Comprimere')
  },
  date: {
    days: 'Domenica_Lunedì_Martedì_Mercoledì_Giovedì_Venerdì_Sabato'.split('_'),
    daysShort: 'Dom_Lun_Mar_Mer_Gio_Ven_Sab'.split('_'),
    months:
      'Gennaio_Febbraio_Marzo_Aprile_Maggio_Giugno_Luglio_Agosto_Settembre_Ottobre_Novembre_Dicembre'.split(
        '_'
      ),
    monthsShort: 'Gen_Feb_Mar_Apr_Mag_Giu_Lug_Ago_Set_Ott_Nov_Dic'.split('_'),
    firstDayOfWeek: 1, // 0-6, 0 - Sunday, 1 Monday, ...
    format24h: true,
    pluralDay: 'giorni',
    prevMonth: 'Mese precedente',
    nextMonth: 'Mese successivo',
    prevYear: 'Anno precedente',
    nextYear: 'Anno successivo',
    today: 'Oggi',
    prevRangeYears: range => `${range} anni precedenti`,
    nextRangeYears: range => `${range} anni successivi`,
    hour: 'Ora',
    minute: 'Minuto',
    second: 'Secondo',
    now: 'Ora corrente'
  },
  table: {
    noData: 'Nessun dato disponibile',
    noResults: 'Nessuna corrispondenza trovata',
    loading: 'Caricamento...',
    selectedRecords: rows =>
      rows > 0
        ? rows +
          ' ' +
          (rows === 1 ? 'riga selezionata' : 'righe selezionate') +
          '.'
        : 'Nessuna riga selezionata.',
    recordsPerPage: 'Righe per pagina:',
    allRows: 'Tutte',
    pagination: (start, end, total) => start + '-' + end + ' di ' + total,
    columns: 'Colonne',
    selectAllRows: 'Seleziona tutte le righe',
    selectRow: 'Seleziona la riga'
  },
  pagination: {
    label: 'Impaginazione',
    first: 'Prima pagina',
    prev: 'Pagina precedente',
    next: 'Pagina successiva',
    last: 'Ultima pagina'
  },
  carousel: {
    prevSlide: 'Diapositiva precedente',
    nextSlide: 'Diapositiva successiva'
  },
  colorPicker: {
    spectrum: 'Spettro',
    tune: 'Regolazione',
    palette: 'Tavolozza',
    value: 'Valore del colore',
    hue: 'Tonalità',
    alpha: 'Opacità',
    saturation: 'Saturazione',
    brightness: 'Luminosità'
  },
  uploader: {
    addFiles: 'Scegli i file',
    upload: 'Carica i file',
    abort: 'Annulla il caricamento',
    removeQueued: 'Rimuovi i file in coda',
    removeUploaded: 'Rimuovi i file caricati',
    removeFile: 'Rimuovi il file'
  },
  editor: {
    toolbar: "Barra degli strumenti dell'editor",
    url: 'URL',
    bold: 'Grassetto',
    italic: 'Corsivo',
    strikethrough: 'Barrato',
    underline: 'Sottolineato',
    unorderedList: 'Lista non ordinata',
    orderedList: 'Lista ordinata',
    subscript: 'Pedice',
    superscript: 'Apice',
    hyperlink: 'Collegamento',
    toggleFullscreen: 'Attiva/disattiva schermo intero',
    quote: 'Citazione',
    left: 'A sinistra',
    center: 'Centra',
    right: 'A destra',
    justify: 'Giustificato',
    print: 'Stampa',
    outdent: 'Diminuisci identazione',
    indent: 'Aumenta identazione',
    removeFormat: 'Rimuovi formattazione',
    formatting: 'Formattazione',
    fontSize: 'Dimensione carattere',
    align: 'Allinea',
    hr: 'Inserisci righello orizzontale',
    undo: 'Annulla',
    redo: 'Ripristina',
    heading1: 'Intestazione 1',
    heading2: 'Intestazione 2',
    heading3: 'Intestazione 3',
    heading4: 'Intestazione 4',
    heading5: 'Intestazione 5',
    heading6: 'Intestazione 6',
    paragraph: 'Paragrafo',
    code: 'Codice',
    size1: 'Molto piccolo',
    size2: 'Piccolo',
    size3: 'Normale',
    size4: 'Medio-largo',
    size5: 'Grande',
    size6: 'Molto grande',
    size7: 'Massimo',
    defaultFont: 'Font predefinito',
    viewSource: 'Vedi sorgente'
  },
  tree: {
    noNodes: 'Nessun nodo disponibile',
    noResults: 'Nessuna corrispondenza trovata'
  }
}
