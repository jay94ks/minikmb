export default {
  isoName: 'fr',
  nativeName: 'Français',
  label: {
    clear: 'Effacer',
    ok: 'OK',
    cancel: 'Annuler',
    close: 'Fermer',
    set: 'Régler',
    select: 'Sélectionner',
    reset: 'Réinitialiser',
    remove: 'Supprimer',
    update: 'Mettre à jour',
    create: 'Créer',
    search: 'Rechercher',
    filter: 'Filtrer',
    refresh: 'Rafraîchir',
    minimum: 'Minimum',
    maximum: 'Maximum',
    range: 'Plage',
    noValue: 'Aucune valeur',
    resize: 'Redimensionner',
    expand: label => (label ? `Développer "${label}"` : 'Développer'),
    collapse: label => (label ? `Réduire "${label}"` : 'Effondrement')
  },
  date: {
    days: 'Dimanche_Lundi_Mardi_Mercredi_Jeudi_Vendredi_Samedi'.split('_'),
    daysShort: 'Dim_Lun_Mar_Mer_Jeu_Ven_Sam'.split('_'),
    months:
      'Janvier_Février_Mars_Avril_Mai_Juin_Juillet_Août_Septembre_Octobre_Novembre_Décembre'.split(
        '_'
      ),
    monthsShort: 'Jan_Fev_Mar_Avr_Mai_Juin_Jui_Aou_Sep_Oct_Nov_Dec'.split('_'),
    headerTitle: date =>
      new Intl.DateTimeFormat('fr', {
        weekday: 'short',
        day: 'numeric',
        month: 'short'
      }).format(date),
    firstDayOfWeek: 1, // 0-6, 0 - Sunday, 1 Monday, ...
    format24h: true,
    pluralDay: 'jours',
    prevMonth: 'Mois précédent',
    nextMonth: 'Mois suivant',
    prevYear: 'Année précédente',
    nextYear: 'Année suivante',
    today: "Aujourd'hui",
    prevRangeYears: range => `${range} années précédentes`,
    nextRangeYears: range => `${range} années suivantes`,
    hour: 'Heure',
    minute: 'Minute',
    second: 'Seconde',
    now: 'Heure actuelle'
  },
  table: {
    noData: 'Aucune donnée à afficher',
    noResults: 'Aucune donnée trouvée',
    loading: 'Chargement...',
    selectedRecords: rows =>
      rows > 0
        ? rows +
          ' ' +
          (rows === 1 ? 'ligne sélectionnée' : 'lignes sélectionnées') +
          '.'
        : 'Aucune ligne sélectionnée.',
    recordsPerPage: 'Lignes par page :',
    allRows: 'Tous',
    pagination: (start, end, total) => start + '-' + end + ' sur ' + total,
    columns: 'Colonnes',
    selectAllRows: 'Sélectionner toutes les lignes',
    selectRow: 'Sélectionner la ligne'
  },
  pagination: {
    label: 'Pagination',
    first: 'Première page',
    prev: 'Page précédente',
    next: 'Page suivante',
    last: 'Dernière page'
  },
  carousel: {
    prevSlide: 'Diapositive précédente',
    nextSlide: 'Diapositive suivante'
  },
  colorPicker: {
    spectrum: 'Spectre',
    tune: 'Réglage',
    palette: 'Palette',
    value: 'Valeur de la couleur',
    hue: 'Teinte',
    alpha: 'Opacité',
    saturation: 'Saturation',
    brightness: 'Luminosité'
  },
  uploader: {
    addFiles: 'Choisir des fichiers',
    upload: 'Téléverser les fichiers',
    abort: 'Annuler le téléversement',
    removeQueued: 'Supprimer les fichiers en attente',
    removeUploaded: 'Supprimer les fichiers téléversés',
    removeFile: 'Supprimer le fichier'
  },
  editor: {
    toolbar: "Barre d'outils de l'éditeur",
    url: 'URL',
    bold: 'Gras',
    italic: 'Italique',
    strikethrough: 'Barré',
    underline: 'Souligné',
    unorderedList: 'Liste non ordonnée',
    orderedList: 'Liste ordonnée',
    subscript: 'Indice',
    superscript: 'Exposant',
    hyperlink: 'Hyperlien',
    toggleFullscreen: 'Basculer en plein écran',
    quote: 'Citation',
    left: 'Aligner à gauche',
    center: 'Aligner au centre',
    right: 'Aligner à droite',
    justify: 'Justifier',
    print: 'Imprimer',
    outdent: "Diminuer l'indentation",
    indent: "Augmenter l'indentation",
    removeFormat: 'Supprimer la mise en forme',
    formatting: 'Mise en forme',
    fontSize: 'Taille de police',
    align: 'Aligner',
    hr: 'Insérer une règle horizontale',
    undo: 'Annuler',
    redo: 'Refaire',
    heading1: 'Titre 1',
    heading2: 'Titre 2',
    heading3: 'Titre 3',
    heading4: 'Titre 4',
    heading5: 'Titre 5',
    heading6: 'Titre 6',
    paragraph: 'Paragraphe',
    code: 'Code',
    size1: 'Très petit',
    size2: 'Petit',
    size3: 'Normal',
    size4: 'Moyenne',
    size5: 'Grand',
    size6: 'Très grand',
    size7: 'Maximum',
    defaultFont: 'Police par défaut',
    viewSource: 'Voir la source'
  },
  tree: {
    noNodes: 'Aucun nœud à afficher',
    noResults: 'Aucun nœud trouvé'
  }
}
