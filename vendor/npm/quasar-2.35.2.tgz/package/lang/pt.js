export default {
  isoName: 'pt',
  nativeName: 'Português',
  label: {
    clear: 'Limpar',
    ok: 'OK',
    cancel: 'Cancelar',
    close: 'Fechar',
    set: 'Marcar',
    select: 'Escolher',
    reset: 'Limpar',
    remove: 'Remover',
    update: 'Atualizar',
    create: 'Criar',
    search: 'Procurar',
    filter: 'Filtrar',
    refresh: 'Recarregar',
    minimum: 'Mínimo',
    maximum: 'Máximo',
    range: 'Intervalo',
    noValue: 'Sem valor',
    resize: 'Redimensionar',
    expand: label => (label ? `Expandir "${label}"` : 'Expandir'),
    collapse: label => (label ? `Recolher "${label}"` : 'Colapso')
  },
  date: {
    days: 'Domingo_Segunda-feira_Terça-feira_Quarta-feira_Quinta-feira_Sexta-feira_Sábado'.split(
      '_'
    ),
    daysShort: 'Dom_Seg_Ter_Qua_Qui_Sex_Sáb'.split('_'),
    months:
      'Janeiro_Fevereiro_Março_Abril_Maio_Junho_Julho_Agosto_Setembro_Outubro_Novembro_Dezembro'.split(
        '_'
      ),
    monthsShort: 'Jan_Fev_Mar_Abr_Mai_Jun_Jul_Ago_Set_Out_Nov_Dez'.split('_'),
    firstDayOfWeek: 1, // 0-6, 0 - Sunday, 1 Monday, ...
    format24h: true,
    pluralDay: 'dias',
    prevMonth: 'Mês anterior',
    nextMonth: 'Próximo mês',
    prevYear: 'Ano anterior',
    nextYear: 'Próximo ano',
    today: 'Hoje',
    prevRangeYears: range => `${range} anos anteriores`,
    nextRangeYears: range => `${range} anos seguintes`,
    hour: 'Hora',
    minute: 'Minuto',
    second: 'Segundo',
    now: 'Hora atual'
  },
  table: {
    noData: 'Sem dados disponíveis',
    noResults: 'Não foi encontrado nenhum resultado',
    loading: 'A carregar...',
    selectedRecords: rows =>
      rows > 0
        ? rows +
          ' linha' +
          (rows === 1 ? ' selecionada' : 's selecionadas') +
          '.'
        : 'Nenhuma linha selecionada.',
    recordsPerPage: 'Linhas por página:',
    allRows: 'Todas',
    pagination: (start, end, total) => start + '-' + end + ' de ' + total,
    columns: 'Colunas',
    selectAllRows: 'Selecionar todas as linhas',
    selectRow: 'Selecionar linha'
  },
  pagination: {
    label: 'Paginação',
    first: 'Primeira página',
    prev: 'Página anterior',
    next: 'Próxima página',
    last: 'Última página'
  },
  carousel: {
    prevSlide: 'Slide anterior',
    nextSlide: 'Próximo slide'
  },
  colorPicker: {
    spectrum: 'Espectro',
    tune: 'Ajuste',
    palette: 'Paleta',
    value: 'Valor da cor',
    hue: 'Matiz',
    alpha: 'Opacidade',
    saturation: 'Saturação',
    brightness: 'Brilho'
  },
  uploader: {
    addFiles: 'Escolher ficheiros',
    upload: 'Carregar ficheiros',
    abort: 'Cancelar o carregamento',
    removeQueued: 'Remover ficheiros em fila',
    removeUploaded: 'Remover ficheiros carregados',
    removeFile: 'Remover ficheiro'
  },
  editor: {
    toolbar: 'Barra de ferramentas do editor',
    url: 'URL',
    bold: 'Negrito',
    italic: 'Itálico',
    strikethrough: 'Rasurado',
    underline: 'Sublinhado',
    unorderedList: 'Lista não-ordenada',
    orderedList: 'Lista ordenada',
    subscript: 'Subscrito',
    superscript: 'Sobrescrito',
    hyperlink: 'Hyperlink',
    toggleFullscreen: 'Maximizar',
    quote: 'Citação',
    left: 'Alinhado à esquerda',
    center: 'Alinhado ao centro',
    right: 'Alinhado à direita',
    justify: 'Justificado',
    print: 'Imprimir',
    outdent: 'Diminuir indentação',
    indent: 'Aumentar indentação',
    removeFormat: 'Remover formatação',
    formatting: 'Formatação',
    fontSize: 'Tamanho do tipo de letra',
    align: 'Alinhar',
    hr: 'Inserir linha horizontal',
    undo: 'Desfazer',
    redo: 'Refazer',
    heading1: 'Cabeçalho 1',
    heading2: 'Cabeçalho 2',
    heading3: 'Cabeçalho 3',
    heading4: 'Cabeçalho 4',
    heading5: 'Cabeçalho 5',
    heading6: 'Cabeçalho 6',
    paragraph: 'Parágrafo',
    code: 'Código',
    size1: 'Muito pequeno',
    size2: 'Pequeno',
    size3: 'Normal',
    size4: 'Médio',
    size5: 'Grande',
    size6: 'Enorme',
    size7: 'Máximo',
    defaultFont: 'Tipo de letra padrão',
    viewSource: 'Exibir fonte'
  },
  tree: {
    noNodes: 'Sem nós disponíveis',
    noResults: 'Nenhum resultado encontrado'
  }
}
