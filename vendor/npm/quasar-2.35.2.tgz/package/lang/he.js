export default {
  isoName: 'he',
  nativeName: 'עברית',
  rtl: true,
  label: {
    clear: 'נקה',
    ok: 'אישור',
    cancel: 'ביטול',
    close: 'סגור',
    set: 'הגדר',
    select: 'בחר',
    reset: 'איפוס',
    remove: 'מחק',
    update: 'עדכן',
    create: 'צור',
    search: 'חיפוש',
    filter: 'סינון',
    refresh: 'רענון',
    minimum: 'מינימום',
    maximum: 'מקסימום',
    range: 'טווח',
    noValue: 'אין ערך',
    resize: 'שינוי גודל',
    expand: label => (label ? `"${label}" הרחב את` : 'לְהַרְחִיב'),
    collapse: label => (label ? `"${label}" כווץ` : 'הִתמוֹטְטוּת')
  },
  date: {
    days: 'ראשון_שני_שלישי_רביעי_חמישי_שישי_שבת'.split('_'),
    daysShort: 'א_ב_ג_ד_ה_ו_ש'.split('_'),
    months:
      'ינואר_פברואר_מרץ_אפריל_מאי_יוני_יולי_אוגוסט_ספטמבר_אוקטובר_נובמבר_דצמבר'.split(
        '_'
      ),
    monthsShort:
      'ינואר_פברואר_מרץ_אפריל_מאי_יוני_יולי_אוגוסט_ספטמבר_אוקטובר_נובמבר_דצמבר'.split(
        '_'
      ),
    firstDayOfWeek: 0, // 0-6, 0 - Sunday, 1 Monday, ...
    format24h: true,
    pluralDay: 'ימים',
    prevMonth: 'החודש הקודם',
    nextMonth: 'בחודש הבא',
    prevYear: 'שנה קודמת',
    nextYear: 'שנה הבאה',
    today: 'הַיוֹם',
    prevRangeYears: range => `קודם ${range} שנים`,
    nextRangeYears: range => `הבא ${range} שנים`,
    hour: 'שעה',
    minute: 'דקה',
    second: 'שנייה',
    now: 'הזמן הנוכחי'
  },
  table: {
    noData: 'לא נמצאו נתונים',
    noResults: 'לא נמצאו תוצאות רלוונטיות',
    loading: 'טוען...',
    selectedRecords: rows =>
      rows === 1
        ? 'נבחרה שורה אחת.'
        : (rows === 0 ? 'לא' : rows) + ' שורות נבחרו',
    recordsPerPage: 'שורות בעמוד:',
    allRows: 'הכל',
    pagination: (start, end, total) => start + ' - ' + end + ' מתוך ' + total,
    columns: 'עמודות',
    selectAllRows: 'בחר את כל השורות',
    selectRow: 'בחר שורה'
  },
  pagination: {
    label: 'עימוד',
    first: 'עמוד ראשון',
    prev: 'עמוד קודם',
    next: 'העמוד הבא',
    last: 'העמוד האחרון'
  },
  carousel: {
    prevSlide: 'השקופית הקודמת',
    nextSlide: 'השקופית הבאה'
  },
  colorPicker: {
    spectrum: 'ספקטרום',
    tune: 'כוונון',
    palette: 'לוח צבעים',
    value: 'ערך הצבע',
    hue: 'גוון',
    alpha: 'אטימות',
    saturation: 'רוויה',
    brightness: 'בהירות'
  },
  uploader: {
    addFiles: 'בחר קבצים',
    upload: 'העלה קבצים',
    abort: 'בטל העלאה',
    removeQueued: 'הסר קבצים בהמתנה',
    removeUploaded: 'הסר קבצים שהועלו',
    removeFile: 'הסר קובץ'
  },
  editor: {
    toolbar: 'סרגל הכלים של העורך',
    url: 'כתובת אתר',
    bold: 'בולט',
    italic: 'נטוי',
    strikethrough: 'קו חוצה',
    underline: 'קו תחתון',
    unorderedList: 'רשימת תבליטים',
    orderedList: 'רשימה ממוספרת',
    subscript: 'קו תחתון',
    superscript: 'קו עליון',
    hyperlink: 'קישור',
    toggleFullscreen: 'מסך מלא',
    quote: 'ציטוט',
    left: 'יישור לשמאל',
    center: 'יישור למרכז',
    right: 'יישור לימין',
    justify: 'יישור',
    print: 'הדפסה',
    outdent: 'הקטן כניסה',
    indent: 'הגדל כניסה',
    removeFormat: 'נקה עיתוב',
    formatting: 'עיצוב',
    fontSize: 'גודל פונט',
    align: 'יישור',
    hr: 'הוסף קו אופקי',
    undo: 'בטל',
    redo: 'בצע מחדש',
    heading1: 'כותרת 1',
    heading2: 'כותרת 2',
    heading3: 'כותרת 3',
    heading4: 'כותרת 4',
    heading5: 'כותרת 5',
    heading6: 'כותרת 6',
    paragraph: 'פסקה',
    code: 'קטע קוד',
    size1: 'קטן מאוד',
    size2: 'קטן',
    size3: 'נורמלי',
    size4: 'בינוני-גדול',
    size5: 'גדול',
    size6: 'גדול מאוד',
    size7: 'מקסימלי',
    defaultFont: 'ברירת מחדל',
    viewSource: 'ראה מקור'
  },
  tree: {
    noNodes: 'אין פריטים להצגה',
    noResults: 'לא נמצאו פריטים רלוונטים'
  }
}
