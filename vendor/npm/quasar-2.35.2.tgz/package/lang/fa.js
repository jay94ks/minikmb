const days = 'یکشنبه_دوشنبه_سه‌شنبه_چهارشنبه_پنجشنبه_جمعه_شنبه'.split('_')
const persianDigits = '۰۱۲۳۴۵۶۷۸۹'
const formatNumber = value =>
  value.replaceAll(/\d/g, digit => persianDigits[digit])
const monthsShort =
  'فروردین_اردیبهشت_خرداد_تیر_مرداد_شهریور_مهر_آبان_آذر_دی_بهمن_اسفند'.split(
    '_'
  )

export default {
  isoName: 'fa',
  nativeName: 'فارسی',
  rtl: true,
  formatNumber,
  label: {
    clear: 'پاک‌سازی',
    ok: 'قبول',
    cancel: 'لغو',
    close: 'بستن',
    set: 'ثبت',
    select: 'انتخاب',
    reset: 'بازنشانی',
    remove: 'حذف',
    update: 'بروزرسانی',
    create: 'ساخت',
    search: 'جستجو',
    filter: 'فیلتر',
    refresh: 'تازه‌سازی',
    minimum: 'کمینه',
    maximum: 'بیشینه',
    range: 'بازه',
    noValue: 'بدون مقدار',
    resize: 'تغییر اندازه',
    expand: label => (label ? `"${label}" گسترش` : 'بسط دادن'),
    collapse: label => (label ? `"${label}" کوچک کردن` : 'سقوط - فروپاشی')
  },
  date: {
    days,
    daysShort: 'ی_د_س_چ_پ_ج_ش'.split('_'),
    months:
      'فروردین_اردیبهشت_خرداد_تیر_مرداد_شهریور_مهر_آبان_آذر_دی_بهمن_اسفند'.split(
        '_'
      ),
    monthsShort,
    headerTitle: (date, model) =>
      `${days[date.getDay()]}، ${formatNumber(String(model.day))} ${monthsShort[model.month - 1]}`,
    firstDayOfWeek: 6,
    format24h: true,
    pluralDay: 'روز',
    prevMonth: 'ماه قبل',
    nextMonth: 'ماه بعد',
    prevYear: 'سال قبل',
    nextYear: 'سال دیگر',
    today: 'امروز',
    prevRangeYears: range => `قبلی ${range} سال`,
    nextRangeYears: range => `بعد ${range} سالها`,
    hour: 'ساعت',
    minute: 'دقیقه',
    second: 'ثانیه',
    now: 'زمان کنونی'
  },
  table: {
    noData: 'اطلاعاتی موجود نیست',
    noResults: 'هیچ موردی یافت نشد',
    loading: 'در حال بارگذاری ...',
    selectedRecords: rows =>
      rows === 0 ? 'رکوردی انتخاب نشده' : rows + ' رکورد انتخاب شده',
    recordsPerPage: 'رکورد در صفحه:',
    allRows: 'همه',
    pagination: (start, end, total) => start + ' - ' + end + ' از ' + total,
    columns: 'ستون',
    selectAllRows: 'انتخاب همه ردیف‌ها',
    selectRow: 'انتخاب ردیف'
  },
  pagination: {
    label: 'صفحه‌بندی',
    first: 'صفحه اول',
    prev: 'صفحه قبلی',
    next: 'صفحه بعدی',
    last: 'صفحه آخر'
  },
  carousel: {
    prevSlide: 'اسلاید قبلی',
    nextSlide: 'اسلاید بعدی'
  },
  colorPicker: {
    spectrum: 'طیف',
    tune: 'تنظیم',
    palette: 'پالت',
    value: 'مقدار رنگ',
    hue: 'فام',
    alpha: 'کدری',
    saturation: 'اشباع',
    brightness: 'روشنایی'
  },
  uploader: {
    addFiles: 'انتخاب فایل‌ها',
    upload: 'بارگذاری فایل‌ها',
    abort: 'لغو بارگذاری',
    removeQueued: 'حذف فایل‌های در صف',
    removeUploaded: 'حذف فایل‌های بارگذاری‌شده',
    removeFile: 'حذف فایل'
  },
  editor: {
    toolbar: 'نوار ابزار ویرایشگر',
    url: 'آدرس',
    bold: 'کلفت',
    italic: 'کج',
    strikethrough: 'خط‌خورده',
    underline: 'زیرخط',
    unorderedList: 'فهرست غیرترتیبی',
    orderedList: 'فهرست ترتیبی',
    subscript: 'زیرنویس',
    superscript: 'بالانویس',
    hyperlink: 'پیوند',
    toggleFullscreen: 'تغییر حالت تمام صفحه',
    quote: 'نقل قول',
    left: 'چپ تراز',
    center: 'وسط تراز',
    right: 'راست تراز',
    justify: 'هم‌تراز',
    print: 'چاپ',
    outdent: 'کاهش دندانه',
    indent: 'افزایش دندانه',
    removeFormat: 'حذف قالب‌بندی',
    formatting: 'قالب‌بندی',
    fontSize: 'اندازه قلم',
    align: 'تراز',
    hr: 'درج خط افقی',
    undo: 'عمل قبلی',
    redo: 'عملی بعدی',
    heading1: 'سرفصل ۱',
    heading2: 'سرفصل ۲',
    heading3: 'سرفصل ۳',
    heading4: 'سرفصل ۴',
    heading5: 'سرفصل ۵',
    heading6: 'سرفصل ۶',
    paragraph: 'پاراگراف',
    code: 'کد',
    size1: 'خیلی کوچک',
    size2: 'کوچک',
    size3: 'معمولی',
    size4: 'متوسط-بزرگ',
    size5: 'بزرگ',
    size6: 'خیلی بزرگ',
    size7: 'بزرگترین',
    defaultFont: 'قلم پیش‌فرض',
    viewSource: 'مشاهده منبع'
  },
  tree: {
    noNodes: 'گره‌ای در دسترس نیست',
    noResults: 'گره‌ای یافت نشد'
  }
}
