import {
  computed,
  getCurrentInstance,
  h,
  nextTick,
  onActivated,
  onBeforeMount,
  onBeforeUnmount,
  onDeactivated,
  ref,
  shallowRef,
  watch
} from 'vue'

import useQuasar from '../../composables/use-quasar/use-quasar.js'

import debounce from '../../utils/debounce/debounce.js'
import { noop } from '../../utils/event/event.js'

const aggBucketSize = 1000

const scrollToEdges = [
  'start',
  'center',
  'end',
  'start-force',
  'center-force',
  'end-force'
]

const filterProto = Array.prototype.filter

const setOverflowAnchor =
  __QUASAR_SSR__ ||
  window.getComputedStyle(document.body).overflowAnchor === void 0
    ? noop
    : function setOverflowAnchor(contentEl, index) {
        if (contentEl === null) return

        if (contentEl._qOverflowAnimationFrame !== void 0) {
          cancelAnimationFrame(contentEl._qOverflowAnimationFrame)
        }

        contentEl._qOverflowAnimationFrame = requestAnimationFrame(() => {
          if (contentEl === null) return

          contentEl._qOverflowAnimationFrame = void 0
          const children = contentEl.children || []

          filterProto
            .call(children, el => el.dataset && el.dataset.qVsAnchor !== void 0)
            .forEach(el => {
              delete el.dataset.qVsAnchor
            })

          const el = children[index]

          if (el?.dataset) {
            el.dataset.qVsAnchor = ''
          }
        })
      }

function sumFn(acc, item) {
  return acc + item
}

function getScrollDetails(
  parent,
  child,
  beforeRef,
  afterRef,
  horizontal,
  rtl,
  stickyStart,
  stickyEnd
) {
  const parentCalc =
      parent === window
        ? document.scrollingElement || document.documentElement
        : parent,
    propRectSize = horizontal ? 'width' : 'height',
    details = {
      scrollStart: 0,
      scrollViewSize: -stickyStart - stickyEnd,
      scrollMaxSize: 0,
      offsetStart: -stickyStart,
      offsetEnd: -stickyEnd
    }

  if (horizontal) {
    if (parent === window) {
      details.scrollStart = window.scrollX
      details.scrollViewSize += document.documentElement.clientWidth
    } else {
      details.scrollStart = parentCalc.scrollLeft
      details.scrollViewSize += parentCalc.clientWidth
    }
    details.scrollMaxSize = parentCalc.scrollWidth

    if (rtl) {
      details.scrollStart = -details.scrollStart
    }
  } else {
    if (parent === window) {
      details.scrollStart = window.scrollY
      details.scrollViewSize += document.documentElement.clientHeight
    } else {
      details.scrollStart = parentCalc.scrollTop
      details.scrollViewSize += parentCalc.clientHeight
    }
    details.scrollMaxSize = parentCalc.scrollHeight
  }

  if (beforeRef !== null) {
    for (
      let el = beforeRef.previousElementSibling;
      el !== null;
      el = el.previousElementSibling
    ) {
      if (!el.classList.contains('q-virtual-scroll--skip')) {
        details.offsetStart += el.getBoundingClientRect()[propRectSize]
      }
    }
  }

  if (afterRef !== null) {
    for (
      let el = afterRef.nextElementSibling;
      el !== null;
      el = el.nextElementSibling
    ) {
      if (!el.classList.contains('q-virtual-scroll--skip')) {
        details.offsetEnd += el.getBoundingClientRect()[propRectSize]
      }
    }
  }

  if (child !== parent) {
    const parentRect = parentCalc.getBoundingClientRect(),
      childRect = child.getBoundingClientRect()

    if (horizontal) {
      details.offsetStart += childRect.left - parentRect.left
      details.offsetEnd -= childRect.width
    } else {
      details.offsetStart += childRect.top - parentRect.top
      details.offsetEnd -= childRect.height
    }

    if (parent !== window) {
      details.offsetStart += details.scrollStart
    }
    details.offsetEnd += details.scrollMaxSize - details.offsetStart
  }

  return details
}

function setScroll(parent, scroll, horizontal, rtl) {
  if (scroll === 'end') {
    scroll = (parent === window ? document.body : parent)[
      horizontal ? 'scrollWidth' : 'scrollHeight'
    ]
  }

  if (parent === window) {
    let left, top

    if (horizontal) {
      if (rtl) {
        scroll = -scroll
      }
      left = scroll
      top = window.scrollY
    } else {
      left = window.scrollX
      top = scroll
    }

    // behavior "instant" so that a scroller with CSS
    // "scroll-behavior: smooth" doesn't turn this positioning into an
    // animation, whose intermediate scroll events would get mistaken
    // for user scrolling (#18168)
    window.scrollTo({ left, top, behavior: 'instant' })
  } else if (horizontal) {
    if (rtl) {
      scroll = -scroll
    }

    parent.scrollTo({ left: scroll, behavior: 'instant' })
  } else {
    parent.scrollTo({ top: scroll, behavior: 'instant' })
  }
}

function sumSize(sizeAgg, size, from, to) {
  if (from >= to) {
    return 0
  }

  const lastTo = size.length,
    fromAgg = Math.floor(from / aggBucketSize),
    toAgg = Math.floor((to - 1) / aggBucketSize) + 1

  let total = 0

  for (let i = fromAgg; i < toAgg; i++) {
    total += sizeAgg[i]
  }

  if (from % aggBucketSize !== 0) {
    for (let i = fromAgg * aggBucketSize; i < from; i++) {
      total -= size[i]
    }
  }

  if (to % aggBucketSize !== 0 && to !== lastTo) {
    const end = Math.min(toAgg * aggBucketSize, lastTo)
    for (let i = to; i < end; i++) {
      total -= size[i]
    }
  }

  return total
}

const commonVirtScrollProps = {
  virtualScrollSliceSize: {
    type: [Number, String],
    default: 10
  },

  virtualScrollSliceRatioBefore: {
    type: [Number, String],
    default: 1
  },

  virtualScrollSliceRatioAfter: {
    type: [Number, String],
    default: 1
  },

  virtualScrollItemSize: {
    type: [Number, String],
    default: 24
  },

  virtualScrollStickySizeStart: {
    type: [Number, String],
    default: 0
  },

  virtualScrollStickySizeEnd: {
    type: [Number, String],
    default: 0
  },

  tableColspan: [Number, String]
}

export const commonVirtScrollPropsList = Object.keys(commonVirtScrollProps)

export const useVirtualScrollProps = {
  virtualScrollHorizontal: Boolean,
  onVirtualScroll: Function,
  ...commonVirtScrollProps
}

export function useVirtualScroll({
  virtualScrollLength,
  getVirtualScrollTarget,
  getVirtualScrollEl,
  virtualScrollItemSizeComputed // optional
}) {
  const vm = getCurrentInstance()

  const { props, emit, proxy } = vm
  const $q = useQuasar()

  let prevScrollStart,
    prevToIndex,
    localScrollViewSize,
    virtualScrollSizesAgg = [],
    virtualScrollSizes

  const virtualScrollPaddingBefore = ref(0)
  const virtualScrollPaddingAfter = ref(0)
  const virtualScrollSliceSizeComputed = ref({})

  const beforeRef = shallowRef(null)
  const afterRef = shallowRef(null)
  const contentRef = shallowRef(null)

  const virtualScrollSliceRange = ref({ from: 0, to: 0 })

  const colspanAttr = computed(() =>
    props.tableColspan !== void 0 ? props.tableColspan : 100
  )

  if (virtualScrollItemSizeComputed === void 0) {
    virtualScrollItemSizeComputed = computed(() => props.virtualScrollItemSize)
  }

  const needsReset = computed(
    () =>
      virtualScrollItemSizeComputed.value + ';' + props.virtualScrollHorizontal
  )

  const needsSliceRecalc = computed(
    () =>
      needsReset.value +
      ';' +
      props.virtualScrollSliceRatioBefore +
      ';' +
      props.virtualScrollSliceRatioAfter
  )

  watch(needsSliceRecalc, () => {
    setVirtualScrollSize()
  })
  watch(needsReset, reset)

  function reset() {
    localResetVirtualScroll(prevToIndex, true)
  }

  function refresh(toIndex) {
    localResetVirtualScroll(toIndex === void 0 ? prevToIndex : toIndex)
  }

  function scrollTo(toIndex, edge) {
    const scrollEl = getVirtualScrollTarget()

    if (scrollEl === void 0 || scrollEl === null || scrollEl.nodeType === 8) {
      return
    }

    // a scroll event still pending its debounce would re-slice for a
    // position this request supersedes, and if it got to run before
    // the frame applying the requested position (a frame slower than
    // the debounce) it would make that frame give up; the applied
    // position fires its own scroll event
    onVirtualScrollEvt.cancel()

    const scrollDetails = getScrollDetails(
      scrollEl,
      getVirtualScrollEl(),
      beforeRef.value,
      afterRef.value,
      props.virtualScrollHorizontal,
      $q.lang.rtl,
      props.virtualScrollStickySizeStart,
      props.virtualScrollStickySizeEnd
    )

    if (localScrollViewSize !== scrollDetails.scrollViewSize) {
      setVirtualScrollSize(scrollDetails.scrollViewSize)
    }

    setVirtualScrollSliceRange(
      scrollEl,
      scrollDetails,
      Math.min(
        virtualScrollLength.value - 1,
        Math.max(0, Number.parseInt(toIndex, 10) || 0)
      ),
      0,
      scrollToEdges.includes(edge)
        ? edge
        : prevToIndex !== -1 && toIndex > prevToIndex
          ? 'end'
          : 'start'
    )
  }

  function localOnVirtualScrollEvt() {
    const scrollEl = getVirtualScrollTarget()

    if (scrollEl === void 0 || scrollEl === null || scrollEl.nodeType === 8) {
      return
    }

    const scrollDetails = getScrollDetails(
        scrollEl,
        getVirtualScrollEl(),
        beforeRef.value,
        afterRef.value,
        props.virtualScrollHorizontal,
        $q.lang.rtl,
        props.virtualScrollStickySizeStart,
        props.virtualScrollStickySizeEnd
      ),
      listLastIndex = virtualScrollLength.value - 1,
      listEndOffset =
        scrollDetails.scrollMaxSize -
        scrollDetails.offsetStart -
        scrollDetails.offsetEnd -
        virtualScrollPaddingAfter.value

    if (prevScrollStart === scrollDetails.scrollStart) return

    if (scrollDetails.scrollMaxSize <= 0) {
      setVirtualScrollSliceRange(scrollEl, scrollDetails, 0, 0)
      return
    }

    if (localScrollViewSize !== scrollDetails.scrollViewSize) {
      setVirtualScrollSize(scrollDetails.scrollViewSize)
    }

    updateVirtualScrollSizes(virtualScrollSliceRange.value.from)

    const scrollMaxStart = Math.floor(
      scrollDetails.scrollMaxSize -
        Math.max(scrollDetails.scrollViewSize, scrollDetails.offsetEnd) -
        Math.min(
          virtualScrollSizes[listLastIndex],
          scrollDetails.scrollViewSize / 2
        )
    )

    if (
      scrollMaxStart > 0 &&
      Math.ceil(scrollDetails.scrollStart) >= scrollMaxStart
    ) {
      setVirtualScrollSliceRange(
        scrollEl,
        scrollDetails,
        listLastIndex,
        scrollDetails.scrollMaxSize -
          scrollDetails.offsetEnd -
          virtualScrollSizesAgg.reduce(sumFn, 0)
      )

      return
    }

    let toIndex = 0,
      listOffset = scrollDetails.scrollStart - scrollDetails.offsetStart,
      offset = listOffset

    if (
      listOffset <= listEndOffset &&
      listOffset + scrollDetails.scrollViewSize >=
        virtualScrollPaddingBefore.value
    ) {
      listOffset -= virtualScrollPaddingBefore.value
      toIndex = virtualScrollSliceRange.value.from
      offset = listOffset
    } else {
      for (
        let j = 0;
        listOffset >= virtualScrollSizesAgg[j] && toIndex < listLastIndex;
        j++
      ) {
        listOffset -= virtualScrollSizesAgg[j]
        toIndex += aggBucketSize
      }
    }

    while (listOffset > 0 && toIndex < listLastIndex) {
      listOffset -= virtualScrollSizes[toIndex]
      if (listOffset > -scrollDetails.scrollViewSize) {
        toIndex++
        offset = listOffset
      } else {
        offset = virtualScrollSizes[toIndex] + listOffset
      }
    }

    setVirtualScrollSliceRange(scrollEl, scrollDetails, toIndex, offset)
  }

  function setVirtualScrollSliceRange(
    scrollEl,
    scrollDetails,
    toIndex,
    offset,
    align
  ) {
    const alignForce = typeof align === 'string' && align.includes('-force')
    const alignEnd = alignForce ? align.replace('-force', '') : align
    const alignRange = alignEnd !== void 0 ? alignEnd : 'start'

    let from = Math.max(
        0,
        toIndex - virtualScrollSliceSizeComputed.value[alignRange]
      ),
      to = from + virtualScrollSliceSizeComputed.value.total

    if (to > virtualScrollLength.value) {
      to = virtualScrollLength.value
      from = Math.max(0, to - virtualScrollSliceSizeComputed.value.total)
    }

    prevScrollStart = scrollDetails.scrollStart

    const rangeChanged =
      from !== virtualScrollSliceRange.value.from ||
      to !== virtualScrollSliceRange.value.to

    if (!rangeChanged && alignEnd === void 0) {
      emitScroll(toIndex)
      return
    }

    const { activeElement } = document
    const contentEl = contentRef.value
    if (
      rangeChanged &&
      contentEl !== null &&
      contentEl !== activeElement &&
      contentEl.contains(activeElement)
    ) {
      contentEl.addEventListener('focusout', onBlurRefocusFn)

      setTimeout(() => {
        contentEl?.removeEventListener('focusout', onBlurRefocusFn)
      }, 0)
    }

    setOverflowAnchor(contentEl, toIndex - from)

    const sizeBefore =
      alignEnd !== void 0
        ? virtualScrollSizes.slice(from, toIndex).reduce(sumFn, 0)
        : 0

    if (rangeChanged) {
      // vue key matching algorithm works only if
      // the array of VNodes changes on only one of the ends
      // so we first change one end and then the other

      const tempTo =
        to >= virtualScrollSliceRange.value.from &&
        from <= virtualScrollSliceRange.value.to
          ? virtualScrollSliceRange.value.to
          : to

      virtualScrollSliceRange.value = { from, to: tempTo }
      virtualScrollPaddingBefore.value = sumSize(
        virtualScrollSizesAgg,
        virtualScrollSizes,
        0,
        from
      )
      virtualScrollPaddingAfter.value = sumSize(
        virtualScrollSizesAgg,
        virtualScrollSizes,
        to,
        virtualScrollLength.value
      )

      requestAnimationFrame(() => {
        if (
          virtualScrollSliceRange.value.to !== to &&
          prevScrollStart === scrollDetails.scrollStart
        ) {
          virtualScrollSliceRange.value = {
            from: virtualScrollSliceRange.value.from,
            to
          }
          virtualScrollPaddingAfter.value = sumSize(
            virtualScrollSizesAgg,
            virtualScrollSizes,
            to,
            virtualScrollLength.value
          )
        }
      })
    }

    requestAnimationFrame(() => {
      // if the scroll was changed give up
      // (another call to setVirtualScrollSliceRange before animation frame)
      if (prevScrollStart !== scrollDetails.scrollStart) return

      if (rangeChanged) {
        updateVirtualScrollSizes(from)
      }

      const sizeAfter = virtualScrollSizes
          .slice(from, toIndex)
          .reduce(sumFn, 0),
        posStart =
          sizeAfter +
          scrollDetails.offsetStart +
          virtualScrollPaddingBefore.value,
        posEnd = posStart + virtualScrollSizes[toIndex]

      let scrollPosition = posStart + offset

      if (alignEnd !== void 0) {
        const sizeDiff = sizeAfter - sizeBefore
        const scrollStart = scrollDetails.scrollStart + sizeDiff

        scrollPosition =
          !alignForce &&
          scrollStart < posStart &&
          posEnd < scrollStart + scrollDetails.scrollViewSize
            ? scrollStart
            : alignEnd === 'end'
              ? posEnd - scrollDetails.scrollViewSize
              : posStart -
                (alignEnd === 'start'
                  ? 0
                  : Math.round(
                      (scrollDetails.scrollViewSize -
                        virtualScrollSizes[toIndex]) /
                        2
                    ))
      }

      prevScrollStart = scrollPosition

      setScroll(
        scrollEl,
        scrollPosition,
        props.virtualScrollHorizontal,
        $q.lang.rtl
      )

      emitScroll(toIndex)
    })
  }

  function updateVirtualScrollSizes(from) {
    const contentEl = contentRef.value

    if (contentEl) {
      const children = filterProto.call(
          contentEl.children,
          el => el.classList && !el.classList.contains('q-virtual-scroll--skip')
        ),
        childrenLength = children.length,
        // measured through the layout rect rather than offsetWidth/Height:
        // those round to integers, and an item with a fractional size (a
        // dense QTable row with its separator is 28.5px) would then drift
        // half a pixel per item between the paddings and the real content,
        // shifting the rows on every re-slice (#15754)
        sizeFn = props.virtualScrollHorizontal
          ? el => el.getBoundingClientRect().width
          : el => el.getBoundingClientRect().height

      let index = from,
        size,
        diff

      for (let i = 0; i < childrenLength;) {
        size = sizeFn(children[i])
        i++

        while (
          i < childrenLength &&
          children[i].classList.contains('q-virtual-scroll--with-prev')
        ) {
          size += sizeFn(children[i])
          i++
        }

        diff = size - virtualScrollSizes[index]

        if (diff !== 0) {
          virtualScrollSizes[index] += diff
          virtualScrollSizesAgg[Math.floor(index / aggBucketSize)] += diff
        }

        index++
      }
    }
  }

  function onBlurRefocusFn() {
    // the content el is taller than the scrollport, so a plain focus()
    // would align its top edge with the scrollport's one
    contentRef.value?.focus({ preventScroll: true })
  }

  function localResetVirtualScroll(toIndex, fullReset) {
    const defaultSize = Number(virtualScrollItemSizeComputed.value)

    if (fullReset || !Array.isArray(virtualScrollSizes)) {
      virtualScrollSizes = []
    }

    const oldVirtualScrollSizesLength = virtualScrollSizes.length

    virtualScrollSizes.length = virtualScrollLength.value

    for (
      let i = virtualScrollLength.value - 1;
      i >= oldVirtualScrollSizesLength;
      i--
    ) {
      virtualScrollSizes[i] = defaultSize
    }

    const jMax = Math.floor((virtualScrollLength.value - 1) / aggBucketSize)
    virtualScrollSizesAgg = []
    for (let j = 0; j <= jMax; j++) {
      let size = 0
      const iMax = Math.min((j + 1) * aggBucketSize, virtualScrollLength.value)
      for (let i = j * aggBucketSize; i < iMax; i++) {
        size += virtualScrollSizes[i]
      }
      virtualScrollSizesAgg.push(size)
    }

    prevToIndex = -1
    prevScrollStart = void 0

    virtualScrollPaddingBefore.value = sumSize(
      virtualScrollSizesAgg,
      virtualScrollSizes,
      0,
      virtualScrollSliceRange.value.from
    )
    virtualScrollPaddingAfter.value = sumSize(
      virtualScrollSizesAgg,
      virtualScrollSizes,
      virtualScrollSliceRange.value.to,
      virtualScrollLength.value
    )

    if (toIndex >= 0) {
      updateVirtualScrollSizes(virtualScrollSliceRange.value.from)
      nextTick(() => {
        scrollTo(toIndex)
      })
    } else {
      onVirtualScrollEvt()
    }
  }

  function setVirtualScrollSize(scrollViewSize) {
    if (scrollViewSize === void 0 && typeof window !== 'undefined') {
      const scrollEl = getVirtualScrollTarget()

      if (scrollEl !== void 0 && scrollEl !== null && scrollEl.nodeType !== 8) {
        scrollViewSize = getScrollDetails(
          scrollEl,
          getVirtualScrollEl(),
          beforeRef.value,
          afterRef.value,
          props.virtualScrollHorizontal,
          $q.lang.rtl,
          props.virtualScrollStickySizeStart,
          props.virtualScrollStickySizeEnd
        ).scrollViewSize
      }
    }

    localScrollViewSize = scrollViewSize

    const virtualScrollSliceRatioBefore =
      Number.parseFloat(props.virtualScrollSliceRatioBefore) || 0
    const virtualScrollSliceRatioAfter =
      Number.parseFloat(props.virtualScrollSliceRatioAfter) || 0
    const multiplier =
      1 + virtualScrollSliceRatioBefore + virtualScrollSliceRatioAfter
    const view =
      scrollViewSize === void 0 || scrollViewSize <= 0
        ? 1
        : Math.ceil(scrollViewSize / virtualScrollItemSizeComputed.value)

    const baseSize = Math.max(
      1,
      view,
      Math.ceil(
        (props.virtualScrollSliceSize > 0 ? props.virtualScrollSliceSize : 10) /
          multiplier
      )
    )

    virtualScrollSliceSizeComputed.value = {
      total: Math.ceil(baseSize * multiplier),
      start: Math.ceil(baseSize * virtualScrollSliceRatioBefore),
      center: Math.ceil(baseSize * (0.5 + virtualScrollSliceRatioBefore)),
      end: Math.ceil(baseSize * (1 + virtualScrollSliceRatioBefore)),
      view
    }
  }

  function padVirtualScroll(tag, content, contentAttrs) {
    const paddingSize = props.virtualScrollHorizontal ? 'width' : 'height'
    const style = {
      ['--q-virtual-scroll-item-' + paddingSize]:
        virtualScrollItemSizeComputed.value + 'px'
    }

    return [
      tag === 'tbody'
        ? h(
            tag,
            {
              class: 'q-virtual-scroll__padding',
              key: 'before',
              ref: beforeRef,
              'aria-hidden': 'true'
            },
            [
              h('tr', [
                h('td', {
                  style: {
                    [paddingSize]: `${virtualScrollPaddingBefore.value}px`,
                    ...style
                  },
                  colspan: colspanAttr.value
                })
              ])
            ]
          )
        : h(tag, {
            class: 'q-virtual-scroll__padding',
            key: 'before',
            ref: beforeRef,
            'aria-hidden': 'true',
            style: {
              [paddingSize]: `${virtualScrollPaddingBefore.value}px`,
              ...style
            }
          }),

      h(
        tag,
        {
          class: 'q-virtual-scroll__content',
          key: 'content',
          ref: contentRef,
          tabindex: -1,
          ...contentAttrs
        },
        content.flat()
      ),

      tag === 'tbody'
        ? h(
            tag,
            {
              class: 'q-virtual-scroll__padding',
              key: 'after',
              ref: afterRef,
              'aria-hidden': 'true'
            },
            [
              h('tr', [
                h('td', {
                  style: {
                    [paddingSize]: `${virtualScrollPaddingAfter.value}px`,
                    ...style
                  },
                  colspan: colspanAttr.value
                })
              ])
            ]
          )
        : h(tag, {
            class: 'q-virtual-scroll__padding',
            key: 'after',
            ref: afterRef,
            'aria-hidden': 'true',
            style: {
              [paddingSize]: `${virtualScrollPaddingAfter.value}px`,
              ...style
            }
          })
    ]
  }

  function emitScroll(index) {
    if (prevToIndex !== index) {
      if (props.onVirtualScroll !== void 0) {
        emit('virtualScroll', {
          index,
          from: virtualScrollSliceRange.value.from,
          to: virtualScrollSliceRange.value.to - 1,
          direction: index < prevToIndex ? 'decrease' : 'increase',
          ref: proxy
        })
      }

      prevToIndex = index
    }
  }

  setVirtualScrollSize()

  // seed the slice with the initial window so the very first render
  // pass already shows content: in the SSR payload, on the hydrating
  // client (which must render the exact same thing) and on the SPA
  // first paint. Derived from props alone — no DOM measurements — so
  // all of those passes agree; the first real measurement re-slices
  // after mount/hydration. The item size can be absent here (e.g.
  // QSelect defines no default), hence the finite check.
  {
    const to = Math.min(
      virtualScrollLength.value,
      virtualScrollSliceSizeComputed.value.total
    )
    const defaultSize = Number(virtualScrollItemSizeComputed.value)

    virtualScrollSliceRange.value = { from: 0, to }
    virtualScrollPaddingAfter.value = Number.isFinite(defaultSize)
      ? Math.max(0, (virtualScrollLength.value - to) * defaultSize)
      : 0
  }

  const onVirtualScrollEvt = debounce(
    localOnVirtualScrollEvt,
    $q.platform.is.ios ? 120 : 35
  )

  onBeforeMount(() => {
    setVirtualScrollSize()
  })

  let shouldActivate = false

  onDeactivated(() => {
    shouldActivate = true
  })

  onActivated(() => {
    if (!shouldActivate) return

    const scrollEl = getVirtualScrollTarget()

    if (
      prevScrollStart !== void 0 &&
      scrollEl !== void 0 &&
      scrollEl !== null &&
      scrollEl.nodeType !== 8
    ) {
      setScroll(
        scrollEl,
        prevScrollStart,
        props.virtualScrollHorizontal,
        $q.lang.rtl
      )
    } else {
      scrollTo(prevToIndex)
    }
  })

  if (!__QUASAR_SSR__) {
    onBeforeUnmount(() => {
      onVirtualScrollEvt.cancel()
    })
  }

  // expose public methods
  Object.assign(proxy, { scrollTo, reset, refresh })

  return {
    virtualScrollSliceRange,
    virtualScrollSliceSizeComputed,

    setVirtualScrollSize,
    onVirtualScrollEvt,
    localResetVirtualScroll,
    padVirtualScroll,

    scrollTo,
    reset,
    refresh
  }
}
