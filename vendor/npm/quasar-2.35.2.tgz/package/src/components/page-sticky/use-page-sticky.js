import { computed, getCurrentInstance, h, inject } from 'vue'

import useQuasar from '../../composables/use-quasar/use-quasar.js'

import { hSlot } from '../../utils/private.render/render.js'
import {
  emptyRenderFn,
  layoutKey
} from '../../utils/private.symbols/symbols.js'

export const usePageStickyProps = {
  position: {
    type: String,
    default: 'bottom-right',
    validator: v =>
      [
        'top-right',
        'top-left',
        'bottom-right',
        'bottom-left',
        'top',
        'right',
        'bottom',
        'left'
      ].includes(v)
  },
  offset: {
    type: Array,
    validator: v => v.length === 2
  },
  expand: Boolean
}

export default function usePageSticky() {
  const { props } = getCurrentInstance()
  const $q = useQuasar()

  const $layout = inject(layoutKey, emptyRenderFn)
  if ($layout === emptyRenderFn) {
    console.error('QPageSticky needs to be child of QLayout')
    return emptyRenderFn
  }

  const attach = computed(() => {
    const pos = props.position

    return {
      top: pos.includes('top'),
      right: pos.includes('right'),
      bottom: pos.includes('bottom'),
      left: pos.includes('left'),
      vertical: pos === 'top' || pos === 'bottom',
      horizontal: pos === 'left' || pos === 'right'
    }
  })

  const top = computed(() => $layout.header.offset)
  const right = computed(() => $layout.right.offset)
  const bottom = computed(() => $layout.footer.offset)
  const left = computed(() => $layout.left.offset)

  const style = computed(() => {
    let posX = 0,
      posY = 0

    const side = attach.value
    const dir = $q.lang.rtl ? -1 : 1

    if (side.top && top.value !== 0) {
      posY = `${top.value}px`
    } else if (side.bottom && bottom.value !== 0) {
      posY = `${-bottom.value}px`
    }

    if (side.left && left.value !== 0) {
      posX = `${dir * left.value}px`
    } else if (side.right && right.value !== 0) {
      posX = `${-dir * right.value}px`
    }

    const css = { transform: `translate(${posX}, ${posY})` }

    if (props.offset) {
      css.margin = `${props.offset[1]}px ${props.offset[0]}px`
    }

    if (side.vertical) {
      if (left.value !== 0) {
        css[$q.lang.rtl ? 'right' : 'left'] = `${left.value}px`
      }
      if (right.value !== 0) {
        css[$q.lang.rtl ? 'left' : 'right'] = `${right.value}px`
      }
    } else if (side.horizontal) {
      if (top.value !== 0) {
        css.top = `${top.value}px`
      }
      if (bottom.value !== 0) {
        css.bottom = `${bottom.value}px`
      }
    }

    return css
  })

  const classes = computed(
    () =>
      `q-page-sticky row flex-center fixed-${props.position}` +
      ` q-page-sticky--${props.expand ? 'expand' : 'shrink'}`
  )

  function getStickyContent(slots) {
    const content = hSlot(slots.default)

    return h(
      'div',
      {
        class: classes.value,
        style: style.value
      },
      props.expand ? content : [h('div', content)]
    )
  }

  return {
    $layout,
    getStickyContent
  }
}
