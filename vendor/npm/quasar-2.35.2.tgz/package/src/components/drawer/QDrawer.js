import {
  computed,
  getCurrentInstance,
  h,
  inject,
  nextTick,
  onBeforeUnmount,
  onMounted,
  ref,
  watch,
  withDirectives
} from 'vue'

import useQuasar from '../../composables/use-quasar/use-quasar.js'
import useHistory from '../../composables/private.use-history/use-history.js'
import useModelToggle, {
  useModelToggleEmits,
  useModelToggleProps
} from '../../composables/private.use-model-toggle/use-model-toggle.js'
import usePreventScroll from '../../composables/private.use-prevent-scroll/use-prevent-scroll.js'
import useTimeout from '../../composables/use-timeout/use-timeout.js'
import useDark, {
  useDarkProps
} from '../../composables/private.use-dark/use-dark.js'

import TouchPan from '../../directives/touch-pan/TouchPan.js'

import { createComponent } from '../../utils/private.create/create.js'
import { between } from '../../utils/format/format.js'
import {
  addEscapeKey,
  removeEscapeKey
} from '../../utils/private.keyboard/escape-key.js'
import { hSlot } from '../../utils/private.render/render.js'
import {
  emptyRenderFn,
  layoutKey
} from '../../utils/private.symbols/symbols.js'

const duration = 150

function updateLocal(prop, val) {
  if (prop.value !== val) {
    prop.value = val
  }
}

export default /*#__PURE__*/ createComponent({
  name: 'QDrawer',

  inheritAttrs: false,

  props: {
    ...useModelToggleProps,
    ...useDarkProps,

    side: {
      type: String,
      default: 'left',
      validator: v => ['left', 'right'].includes(v)
    },

    width: {
      type: Number,
      default: 300
    },

    mini: Boolean,
    miniToOverlay: Boolean,
    miniWidth: {
      type: Number,
      default: 57
    },
    noMiniAnimation: Boolean,

    breakpoint: {
      type: Number,
      default: 1023
    },
    showIfAbove: Boolean,

    behavior: {
      type: String,
      validator: v => ['default', 'desktop', 'mobile'].includes(v),
      default: 'default'
    },

    bordered: Boolean,
    elevated: Boolean,

    overlay: Boolean,
    persistent: Boolean,
    noSwipeOpen: Boolean,
    noSwipeClose: Boolean,
    noSwipeBackdrop: Boolean
  },

  emits: [...useModelToggleEmits, 'onLayout', 'miniState', 'escapeKey', 'pan'],

  setup(props, { slots, emit, attrs }) {
    const vm = getCurrentInstance()
    const $q = useQuasar()

    const isDark = useDark(props, $q)
    const { preventBodyScroll } = usePreventScroll()
    const { registerTimeout, removeTimeout } = useTimeout()

    const $layout = inject(layoutKey, emptyRenderFn)
    if ($layout === emptyRenderFn) {
      console.error('QDrawer needs to be child of QLayout')
      return emptyRenderFn
    }

    let lastDesktopState,
      timerMini = null,
      layoutTotalWidthWatcher

    const belowBreakpoint = ref(
      props.behavior === 'mobile' ||
        (props.behavior !== 'desktop' &&
          $layout.totalWidth.value <= props.breakpoint)
    )

    const isMini = computed(() => props.mini && !belowBreakpoint.value)
    const size = computed(() => (isMini.value ? props.miniWidth : props.width))
    const fixed = computed(
      () =>
        props.overlay ||
        props.miniToOverlay ||
        $layout.view.value.includes(rightSide.value ? 'R' : 'L') ||
        ($q.platform.is.ios && $layout.isContainer.value)
    )

    const showing = ref(
      (props.showIfAbove && !belowBreakpoint.value) || props.modelValue === true
    )

    const onLayout = computed(
      () => !props.overlay && showing.value && !belowBreakpoint.value
    )

    const onScreenOverlay = computed(
      () => props.overlay && showing.value && !belowBreakpoint.value
    )

    const hideOnRouteChange = computed(
      () =>
        !props.persistent && (belowBreakpoint.value || onScreenOverlay.value)
    )

    function handleShow(evt, noEvent) {
      addToHistory()

      if (evt !== false) $layout.animate()
      applyPosition(0)

      if (belowBreakpoint.value) {
        const otherInstance = $layout.instances[otherSide.value]
        // the layout holds the raw instance, so this is the ref itself
        if (otherInstance?.belowBreakpoint.value) {
          otherInstance.hide(false)
        }

        applyBackdrop(1)
        if (!$layout.isContainer.value) preventBodyScroll(true)
      } else {
        applyBackdrop(0)
        if (evt !== false) setScrollable(false)
      }

      registerTimeout(() => {
        if (evt !== false) setScrollable(true)
        if (!noEvent) emit('show', evt)
      }, duration)
    }

    function handleHide(evt, noEvent) {
      removeFromHistory()

      if (evt !== false) $layout.animate()

      applyBackdrop(0)
      applyPosition(stateDirection.value * size.value)

      cleanup()

      if (!noEvent) {
        registerTimeout(() => {
          emit('hide', evt)
        }, duration)
      } else {
        removeTimeout()
      }
    }

    const { show, hide } = useModelToggle({
      showing,
      hideOnRouteChange,
      handleShow,
      handleHide
    })

    const { addToHistory, removeFromHistory } = useHistory(
      showing,
      hide,
      hideOnRouteChange
    )

    // In its modal state (below breakpoint or shown overlay) the drawer is
    // dismissed through pointer-only paths (backdrop click, swipe); WCAG
    // asks for a keyboard path as well, so ESCAPE closes it -- under the
    // same conditions, non-persistent only (mobile keeps the back button
    // through the History plugin)
    const escapeState = computed(() => showing.value && hideOnRouteChange.value)

    function onEscapeKey(evt) {
      emit('escapeKey')
      hide(evt)
    }

    function applyEscapeKey(val) {
      // a watcher only fires on value changes, so add/remove
      // strictly alternate and can never double-register
      if (val) {
        addEscapeKey(onEscapeKey)
      } else {
        removeEscapeKey(onEscapeKey)
      }
    }

    const instance = {
      belowBreakpoint,
      hide
    }

    const rightSide = computed(() => props.side === 'right')

    const stateDirection = computed(
      () => ($q.lang.rtl ? -1 : 1) * (rightSide.value ? 1 : -1)
    )

    const flagBackdropBg = ref(0)
    const flagPanning = ref(false)
    const flagMiniAnimate = ref(false)
    const flagContentPosition = ref(
      // starting with "hidden" for SSR/SSG
      size.value * stateDirection.value
    )

    const otherSide = computed(() => (rightSide.value ? 'left' : 'right'))
    const offset = computed(() =>
      showing.value && !belowBreakpoint.value && !props.overlay
        ? props.miniToOverlay
          ? props.miniWidth
          : size.value
        : 0
    )

    const backdropClass = computed(
      () =>
        'fullscreen q-drawer__backdrop' +
        (!showing.value && !flagPanning.value ? ' hidden' : '')
    )

    const backdropStyle = computed(() => ({
      backgroundColor: `rgba(0,0,0,${flagBackdropBg.value * 0.4})`
    }))

    const headerSlot = computed(() =>
      rightSide.value
        ? $layout.rows.value.top[2] === 'r'
        : $layout.rows.value.top[0] === 'l'
    )

    const footerSlot = computed(() =>
      rightSide.value
        ? $layout.rows.value.bottom[2] === 'r'
        : $layout.rows.value.bottom[0] === 'l'
    )

    const aboveStyle = computed(() => {
      const css = {}

      if ($layout.header.space && !headerSlot.value) {
        if (fixed.value) {
          css.top = `${$layout.header.offset}px`
        } else if ($layout.header.space) {
          css.top = `${$layout.header.size}px`
        }
      }

      if ($layout.footer.space && !footerSlot.value) {
        if (fixed.value) {
          css.bottom = `${$layout.footer.offset}px`
        } else if ($layout.footer.space) {
          css.bottom = `${$layout.footer.size}px`
        }
      }

      return css
    })

    const style = computed(() => {
      const acc = {
        '--q-drawer-width': `${size.value}px`,
        transform: `translateX(${flagContentPosition.value}px)`
      }

      return belowBreakpoint.value ? acc : Object.assign(acc, aboveStyle.value)
    })

    const contentClass = computed(
      () =>
        'q-drawer__content fit ' +
        ($layout.isContainer.value ? 'overflow-auto' : 'scroll')
    )

    const classes = computed(
      () =>
        `q-drawer q-drawer--${props.side}` +
        (flagMiniAnimate.value ? ' q-drawer--mini-animate' : '') +
        (props.bordered ? ' q-drawer--bordered' : '') +
        (isDark() ? ' q-drawer--dark q-dark' : '') +
        (flagPanning.value
          ? ' no-transition'
          : showing.value
            ? ''
            : ' q-layout--prevent-focus') +
        (belowBreakpoint.value
          ? ' fixed q-drawer--on-top q-drawer--mobile q-drawer--top-padding'
          : ` q-drawer--${isMini.value ? 'mini' : 'standard'}` +
            (fixed.value || !onLayout.value ? ' fixed' : '') +
            (props.overlay || props.miniToOverlay ? ' q-drawer--on-top' : '') +
            (headerSlot.value ? ' q-drawer--top-padding' : ''))
    )

    const openDirective = computed(() => {
      // if props.noSwipeOpen !== true
      const dir = $q.lang.rtl ? props.side : otherSide.value

      return [
        [
          TouchPan,
          onOpenPan,
          void 0,
          {
            [dir]: true,
            mouse: true,
            // the strip sits on the screen edge, where iOS Safari runs
            // its back/forward navigation swipe; cancelling the detected
            // pan's touchmove is what keeps the browser out of it
            prevent: true
          }
        ]
      ]
    })

    const contentCloseDirective = computed(() => {
      const dir = $q.lang.rtl ? otherSide.value : props.side

      return [
        [
          TouchPan,
          // TouchPan only acquires gestures while its value is a function,
          // so above the breakpoint or with no-swipe-close it gets disabled
          // in place; keying the directive on either would remount the whole
          // drawer content on every change (#17099, #12668)
          belowBreakpoint.value && !props.noSwipeClose ? onClosePan : void 0,
          void 0,
          {
            [dir]: true,
            mouse: true
          }
        ]
      ]
    })

    const backdropCloseDirective = computed(() => {
      const dir = $q.lang.rtl ? otherSide.value : props.side

      return [
        [
          TouchPan,
          // disarmed in place while hidden or with no-swipe-backdrop, so the
          // backdrop element persists across open/close instead of being
          // re-created on every toggle
          showing.value && !props.noSwipeBackdrop ? onClosePan : void 0,
          void 0,
          {
            [dir]: true,
            mouse: true,
            mouseAllDir: true,
            // the backdrop reaches the opposite screen edge, see the
            // opener directive
            prevent: true
          }
        ]
      ]
    })

    function updateBelowBreakpoint() {
      updateLocal(
        belowBreakpoint,
        props.behavior === 'mobile' ||
          (props.behavior !== 'desktop' &&
            $layout.totalWidth.value <= props.breakpoint)
      )
    }

    watch(belowBreakpoint, val => {
      if (val) {
        // from lg to xs
        lastDesktopState = showing.value
        if (showing.value) hide(false)
      } else if (showing.value) {
        // from xs to lg; a drawer opened below the breakpoint holds the
        // body scroll lock and the backdrop, both of which must go
        // regardless of how it was left on desktop (#16651)
        applyPosition(0)
        applyBackdrop(0)
        cleanup()
      } else if (
        !props.overlay &&
        props.behavior !== 'mobile' &&
        lastDesktopState !== false
      ) {
        show(false)
      }
    })

    watch(
      () => props.side,
      (newSide, oldSide) => {
        if ($layout.instances[oldSide] === instance) {
          $layout.instances[oldSide] = void 0
          $layout[oldSide].space = false
          $layout[oldSide].offset = 0
        }

        $layout.instances[newSide] = instance
        $layout[newSide].size = size.value
        $layout[newSide].space = onLayout.value
        $layout[newSide].offset = offset.value
      }
    )

    watch($layout.totalWidth, () => {
      if ($layout.isContainer.value || !document.qScrollPrevented) {
        updateBelowBreakpoint()
      }
    })

    watch(() => props.behavior + props.breakpoint, updateBelowBreakpoint)

    watch($layout.isContainer, val => {
      if (showing.value) preventBodyScroll(!val)
      if (val) updateBelowBreakpoint()
    })

    watch($layout.scrollbarWidth, () => {
      applyPosition(showing.value ? 0 : void 0)
    })

    watch(offset, val => {
      updateLayout('offset', val)
    })

    watch(onLayout, val => {
      emit('onLayout', val)
      updateLayout('space', val)
    })

    watch(rightSide, () => {
      applyPosition()
    })

    watch(size, val => {
      applyPosition()
      updateSizeOnLayout(props.miniToOverlay, val)
    })

    watch(
      () => props.miniToOverlay,
      val => {
        updateSizeOnLayout(val, size.value)
      }
    )

    watch(
      () => $q.lang.rtl,
      () => {
        applyPosition()
      }
    )

    watch(
      () => props.mini,
      () => {
        if (props.noMiniAnimation) return
        if (props.modelValue) {
          animateMini()
          $layout.animate()
        }
      }
    )

    watch(isMini, val => {
      emit('miniState', val)
    })

    function applyPosition(position) {
      if (position === void 0) {
        nextTick(() => {
          position = showing.value ? 0 : size.value
          applyPosition(stateDirection.value * position)
        })
      } else {
        if (
          $layout.isContainer.value &&
          rightSide.value &&
          (belowBreakpoint.value || Math.abs(position) === size.value)
        ) {
          position += stateDirection.value * $layout.scrollbarWidth.value
        }

        flagContentPosition.value = position
      }
    }

    function applyBackdrop(x) {
      flagBackdropBg.value = x
    }

    function setScrollable(v) {
      const action = v ? 'remove' : $layout.isContainer.value ? '' : 'add'

      if (action !== '') {
        document.body.classList[action]('q-body--drawer-toggle')
      }
    }

    function animateMini() {
      if (timerMini !== null) clearTimeout(timerMini)

      if (vm.proxy && vm.proxy.$el) {
        // need to speed it up and apply it immediately,
        // even faster than Vue's nextTick!
        vm.proxy.$el.classList.add('q-drawer--mini-animate')
      }

      flagMiniAnimate.value = true
      timerMini = setTimeout(() => {
        timerMini = null
        flagMiniAnimate.value = false
        vm?.proxy?.$el?.classList.remove('q-drawer--mini-animate')
      }, 150)
    }

    function onOpenPan(evt) {
      // some browsers might capture and trigger this
      // even if Drawer has just been opened (but animation is still pending)
      if (showing.value) return

      const width = size.value,
        position = between(evt.distance.x, 0, width)

      if (evt.isFinal) {
        const opened = position >= Math.min(75, width)

        if (opened) {
          show()
          emit('pan', { type: 'open', stage: 'end' })
        } else {
          $layout.animate()
          applyBackdrop(0)
          applyPosition(stateDirection.value * width)
          emit('pan', { type: 'open', stage: 'cancel' })
        }

        flagPanning.value = false
        return
      }

      applyPosition(
        ($q.lang.rtl ? !rightSide.value : rightSide.value)
          ? Math.max(width - position, 0)
          : Math.min(0, position - width)
      )
      applyBackdrop(between(position / width, 0, 1))

      if (evt.isFirst) {
        flagPanning.value = true
        emit('pan', { type: 'open', stage: 'start' })
      }
    }

    function onClosePan(evt) {
      // some browsers might capture and trigger this
      // even if Drawer has just been closed (but animation is still pending)
      if (!showing.value) return

      const width = size.value,
        dir = evt.direction === props.side,
        position = ($q.lang.rtl ? !dir : dir)
          ? between(evt.distance.x, 0, width)
          : 0

      if (evt.isFinal) {
        const opened = Math.abs(position) < Math.min(75, width)

        if (opened) {
          $layout.animate()
          applyBackdrop(1)
          applyPosition(0)
          emit('pan', { type: 'close', stage: 'cancel' })
        } else {
          hide()
          emit('pan', { type: 'close', stage: 'end' })
        }

        flagPanning.value = false
        return
      }

      applyPosition(stateDirection.value * position)
      applyBackdrop(between(1 - position / width, 0, 1))

      if (evt.isFirst) {
        flagPanning.value = true
        emit('pan', { type: 'close', stage: 'start' })
      }
    }

    function cleanup() {
      preventBodyScroll(false)
      setScrollable(true)
    }

    function updateLayout(prop, val) {
      $layout.update(props.side, prop, val)
    }

    function updateSizeOnLayout(miniToOverlay, newSize) {
      updateLayout('size', miniToOverlay ? props.miniWidth : newSize)
    }

    $layout.instances[props.side] = instance
    updateSizeOnLayout(props.miniToOverlay, size.value)
    updateLayout('space', onLayout.value)
    updateLayout('offset', offset.value)

    if (
      props.showIfAbove &&
      !props.modelValue &&
      showing.value &&
      props['onUpdate:modelValue'] !== void 0
    ) {
      emit('update:modelValue', true)
    }

    onMounted(() => {
      emit('onLayout', onLayout.value)
      emit('miniState', isMini.value)

      // registered on mount so that it stays a client-only concern
      // (a drawer can start out already shown below its breakpoint)
      watch(escapeState, applyEscapeKey, { immediate: true })

      lastDesktopState = props.showIfAbove

      const fn = () => {
        const action = showing.value ? handleShow : handleHide
        action(false, true)
      }

      if ($layout.totalWidth.value !== 0) {
        // make sure that all computed properties
        // have been updated before calling handleShow/handleHide()
        nextTick(fn)
        return
      }

      layoutTotalWidthWatcher = watch($layout.totalWidth, () => {
        layoutTotalWidthWatcher()
        layoutTotalWidthWatcher = void 0

        if (!showing.value && props.showIfAbove && !belowBreakpoint.value) {
          show(false)
        } else {
          fn()
        }
      })
    })

    onBeforeUnmount(() => {
      layoutTotalWidthWatcher?.()
      removeEscapeKey(onEscapeKey)

      if (timerMini !== null) {
        clearTimeout(timerMini)
        timerMini = null
      }

      if (showing.value) cleanup()

      if ($layout.instances[props.side] === instance) {
        $layout.instances[props.side] = void 0
        updateLayout('size', 0)
        updateLayout('offset', 0)
        updateLayout('space', false)
      }
    })

    return () => {
      const child = []

      if (belowBreakpoint.value) {
        if (!props.noSwipeOpen) {
          child.push(
            withDirectives(
              h('div', {
                key: 'open',
                class: `q-drawer__opener fixed-${props.side}`,
                'aria-hidden': 'true'
              }),
              openDirective.value
            )
          )
        }

        child.push(
          withDirectives(
            h('div', {
              ref: 'backdrop',
              class: backdropClass.value,
              style: backdropStyle.value,
              'aria-hidden': 'true',
              onClick: hide
            }),
            backdropCloseDirective.value
          )
        )
      }

      // the aside is the exposed landmark, so role and aria-* describe
      // it and must land on it; everything else (id, data-*, listeners)
      // keeps targeting the scrolling content element
      const asideAttrs = {}
      const contentAttrs = {}
      for (const key in attrs) {
        if (key === 'role' || key.startsWith('aria-')) {
          asideAttrs[key] = attrs[key]
        } else {
          contentAttrs[key] = attrs[key]
        }
      }

      const mini = isMini.value && slots.mini !== void 0
      const content = [
        h(
          'div',
          {
            ...contentAttrs,
            key: String(mini), // required otherwise Vue will not diff correctly
            class: [contentClass.value, attrs.class]
          },
          mini ? slots.mini() : hSlot(slots.default)
        )
      ]

      if (props.elevated && showing.value) {
        content.push(
          h('div', {
            class:
              'q-layout__shadow absolute-full overflow-hidden no-pointer-events'
          })
        )
      }

      child.push(
        withDirectives(
          h(
            'aside',
            {
              ref: 'content',
              class: classes.value,
              style: style.value,
              ...asideAttrs
            },
            content
          ),
          contentCloseDirective.value
        )
      )

      return h('div', { class: 'q-drawer-container' }, child)
    }
  }
})
