import { Fragment, computed, getCurrentInstance, h, ref, watch } from 'vue'

import QBtn from '../btn/QBtn.js'
import QInput from '../input/QInput.js'

import useQuasar from '../../composables/use-quasar/use-quasar.js'
import useDark, {
  useDarkProps
} from '../../composables/private.use-dark/use-dark.js'
import { btnDesignOptions, btnPadding, getBtnDesign } from '../btn/use-btn.js'

import { createComponent } from '../../utils/private.create/create.js'
import { between } from '../../utils/format/format.js'
import { isKeyCode } from '../../utils/private.keyboard/key-composition.js'

function getBool(val, otherwise) {
  return val === true || val === false ? val : otherwise
}

export default /*#__PURE__*/ createComponent({
  name: 'QPagination',

  props: {
    ...useDarkProps,

    modelValue: {
      type: Number,
      required: true
    },
    min: {
      type: [Number, String],
      default: 1
    },
    max: {
      type: [Number, String],
      required: true
    },
    maxPages: {
      type: [Number, String],
      default: 0,
      validator: v => (typeof v === 'string' ? Number.parseInt(v, 10) : v) >= 0
    },

    inputStyle: [Array, String, Object],
    inputClass: [Array, String, Object],

    size: String,

    disable: Boolean,

    input: Boolean,

    iconPrev: String,
    iconNext: String,
    iconFirst: String,
    iconLast: String,

    toFn: Function,

    boundaryLinks: {
      type: Boolean,
      default: null
    },
    boundaryNumbers: {
      type: Boolean,
      default: null
    },
    directionLinks: {
      type: Boolean,
      default: null
    },
    ellipses: {
      type: Boolean,
      default: null
    },

    ripple: {
      type: [Boolean, Object],
      default: null
    },

    round: Boolean,
    rounded: Boolean,

    flat: Boolean,
    outline: Boolean,
    unelevated: Boolean,
    push: Boolean,
    glossy: Boolean,

    color: {
      type: String,
      default: 'primary'
    },
    textColor: String,

    activeDesign: {
      type: String,
      default: '',
      values: v => v === '' || btnDesignOptions.includes(v)
    },
    activeColor: String,
    activeTextColor: String,

    gutter: String,
    padding: {
      type: String,
      default: '3px 2px'
    }
  },

  emits: ['update:modelValue'],

  setup(props, { slots, emit }) {
    const { proxy } = getCurrentInstance()
    const $q = useQuasar()

    const isDark = useDark(props, $q)

    const minProp = computed(() => Number.parseInt(props.min, 10))
    const maxProp = computed(() => Number.parseInt(props.max, 10))
    const maxPagesProp = computed(() => Number.parseInt(props.maxPages, 10))

    const inputPlaceholder = computed(() => model.value + ' / ' + maxProp.value)
    const boundaryLinksProp = computed(() =>
      getBool(props.boundaryLinks, props.input)
    )
    const boundaryNumbersProp = computed(() =>
      getBool(props.boundaryNumbers, !props.input)
    )
    const directionLinksProp = computed(() =>
      getBool(props.directionLinks, props.input)
    )
    const ellipsesProp = computed(() => getBool(props.ellipses, !props.input))

    const newPage = ref(null)
    const model = computed({
      get: () => props.modelValue,
      set: val => {
        val = Number.parseInt(val, 10)
        if (props.disable || !Number.isFinite(val)) return

        const value = between(val, minProp.value, maxProp.value)
        if (props.modelValue !== value) {
          emit('update:modelValue', value)
        }
      }
    })

    watch(
      () => `${minProp.value}|${maxProp.value}`,
      () => {
        model.value = props.modelValue
      }
    )

    const classes = computed(
      () =>
        'q-pagination row no-wrap items-center' +
        (props.disable ? ' disabled' : '')
    )

    const gutterProp = computed(() =>
      props.gutter in btnPadding
        ? `${btnPadding[props.gutter]}px`
        : props.gutter || null
    )
    const gutterStyle = computed(() =>
      gutterProp.value !== null
        ? `--q-pagination-gutter-parent:-${gutterProp.value};--q-pagination-gutter-child:${gutterProp.value}`
        : null
    )

    const icons = computed(() => {
      const ico = [
        props.iconFirst || $q.iconSet.pagination.first,
        props.iconPrev || $q.iconSet.pagination.prev,
        props.iconNext || $q.iconSet.pagination.next,
        props.iconLast || $q.iconSet.pagination.last
      ]
      return $q.lang.rtl ? ico.reverse() : ico
    })

    const attrs = computed(() => ({
      'aria-disabled': props.disable ? 'true' : 'false',
      role: 'navigation',
      // an unnamed navigation landmark is indistinguishable from any other
      'aria-label': $q.lang.pagination.label
    }))

    const btnDesignProp = computed(() => getBtnDesign(props, 'flat'))
    const btnProps = computed(() => ({
      [btnDesignProp.value]: true,

      round: props.round,
      rounded: props.rounded,
      glossy: props.glossy,

      padding: props.padding,

      color: props.color,
      textColor: props.textColor,

      size: props.size,
      ripple: props.ripple !== null ? props.ripple : true
    }))

    const btnActiveDesignProp = computed(() => {
      // we also reset non-active design
      const acc = { [btnDesignProp.value]: false }
      if (props.activeDesign !== '') {
        acc[props.activeDesign] = true
      }
      return acc
    })
    const activeBtnProps = computed(() => ({
      ...btnActiveDesignProp.value,
      color: props.activeColor || props.color,
      textColor: props.activeTextColor || props.textColor
    }))

    const btnConfig = computed(() => {
      let maxPages = Math.max(
        maxPagesProp.value,
        1 + (ellipsesProp.value ? 2 : 0) + (boundaryNumbersProp.value ? 2 : 0)
      )

      const acc = {
        pgFrom: minProp.value,
        pgTo: maxProp.value,
        ellipsesStart: false,
        ellipsesEnd: false,
        boundaryStart: false,
        boundaryEnd: false,
        marginalStyle: {
          minWidth: `${Math.max(2, String(maxProp.value).length)}em`
        }
      }

      if (maxPagesProp.value && maxPages < maxProp.value - minProp.value + 1) {
        maxPages = 1 + Math.floor(maxPages / 2) * 2
        acc.pgFrom = Math.max(
          minProp.value,
          Math.min(
            maxProp.value - maxPages + 1,
            props.modelValue - Math.floor(maxPages / 2)
          )
        )
        acc.pgTo = Math.min(maxProp.value, acc.pgFrom + maxPages - 1)

        if (boundaryNumbersProp.value) {
          acc.boundaryStart = true
          acc.pgFrom++
        }

        if (
          ellipsesProp.value &&
          acc.pgFrom > minProp.value + (boundaryNumbersProp.value ? 1 : 0)
        ) {
          acc.ellipsesStart = true
          acc.pgFrom++
        }

        if (boundaryNumbersProp.value) {
          acc.boundaryEnd = true
          acc.pgTo--
        }

        if (
          ellipsesProp.value &&
          acc.pgTo < maxProp.value - (boundaryNumbersProp.value ? 1 : 0)
        ) {
          acc.ellipsesEnd = true
          acc.pgTo--
        }
      }

      return acc
    })

    function set(value) {
      model.value = value
    }

    function setByOffset(offset) {
      model.value = model.value + offset
    }

    function updateModel() {
      model.value = newPage.value
      newPage.value = null
      if ($q.platform.is.mobile) document.activeElement.blur()
    }

    function onInputValue(val) {
      newPage.value = val
    }

    function onKeyup(e) {
      if (isKeyCode(e, 13)) updateModel()
    }

    // display-only: the model and the input stay numeric
    function fmtNum(value) {
      const str = String(value)
      return $q.lang.formatNumber?.(str) ?? str
    }

    function getBtnData(cfg, page, active) {
      const data = {
        'aria-label': fmtNum(page),
        ...btnProps.value,
        ...cfg
      }

      if (active) {
        Object.assign(data, {
          'aria-current': 'page',
          ...activeBtnProps.value
        })
      }

      return data
    }

    function getBtn(cfg, page, active) {
      const data = getBtnData(cfg, page, active)

      if (page !== void 0) {
        if (props.toFn !== void 0) {
          data.to = props.toFn(page)
        } else {
          data.onClick = () => {
            set(page)
          }
        }
      }

      return h(QBtn, data)
    }

    function getEllipsis(side, page, style) {
      const key = side === 'start' ? 'bes' : 'bee'
      const cfg = {
        style,
        disable: props.disable,
        label: '…',
        ripple: false
      }

      if (slots.ellipsis === void 0) {
        return getBtn({ key, ...cfg }, page)
      }

      const scope = {
        side,
        page,
        btnProps: getBtnData(cfg, page),
        onClick: () => {
          set(page)
        }
      }

      if (props.toFn !== void 0) {
        scope.to = props.toFn(page)
      }

      return h(Fragment, { key }, slots.ellipsis(scope))
    }

    // expose public methods
    Object.assign(proxy, { set, setByOffset })

    return () => {
      const contentStart = []
      const contentEnd = []
      let contentMiddle

      if (boundaryLinksProp.value) {
        contentStart.push(
          getBtn(
            {
              key: 'bls',
              disable: props.disable || props.modelValue <= minProp.value,
              icon: icons.value[0],
              'aria-label': $q.lang.pagination.first
            },
            minProp.value
          )
        )

        contentEnd.unshift(
          getBtn(
            {
              key: 'ble',
              disable: props.disable || props.modelValue >= maxProp.value,
              icon: icons.value[3],
              'aria-label': $q.lang.pagination.last
            },
            maxProp.value
          )
        )
      }

      if (directionLinksProp.value) {
        contentStart.push(
          getBtn(
            {
              key: 'bdp',
              disable: props.disable || props.modelValue <= minProp.value,
              icon: icons.value[1],
              'aria-label': $q.lang.pagination.prev
            },
            props.modelValue - 1
          )
        )

        contentEnd.unshift(
          getBtn(
            {
              key: 'bdn',
              disable: props.disable || props.modelValue >= maxProp.value,
              icon: icons.value[2],
              'aria-label': $q.lang.pagination.next
            },
            props.modelValue + 1
          )
        )
      }

      if (!props.input) {
        // has buttons instead of inputbox
        contentMiddle = []
        const { pgFrom, pgTo, marginalStyle: style } = btnConfig.value

        if (btnConfig.value.boundaryStart) {
          contentStart.push(
            getBtn(
              {
                key: 'bns',
                style,
                disable: props.disable,
                label: fmtNum(minProp.value)
              },
              minProp.value,
              minProp.value === props.modelValue
            )
          )
        }

        if (btnConfig.value.boundaryEnd) {
          contentEnd.unshift(
            getBtn(
              {
                key: 'bne',
                style,
                disable: props.disable,
                label: fmtNum(maxProp.value)
              },
              maxProp.value,
              maxProp.value === props.modelValue
            )
          )
        }

        if (btnConfig.value.ellipsesStart) {
          contentStart.push(getEllipsis('start', pgFrom - 1, style))
        }

        if (btnConfig.value.ellipsesEnd) {
          contentEnd.unshift(getEllipsis('end', pgTo + 1, style))
        }

        for (let i = pgFrom; i <= pgTo; i++) {
          contentMiddle.push(
            getBtn(
              {
                key: `bpg${i}`,
                style,
                disable: props.disable,
                label: fmtNum(i)
              },
              i,
              i === props.modelValue
            )
          )
        }
      }

      return h(
        'div',
        {
          class: classes.value,
          ...attrs.value
        },
        [
          h(
            'div',
            {
              class: 'q-pagination__content row no-wrap items-center',
              style: gutterStyle.value
            },
            [
              ...contentStart,

              props.input
                ? h(QInput, {
                    class: 'inline',
                    style: {
                      width: `${inputPlaceholder.value.length / 1.5}em`
                    },
                    type: 'number',
                    dense: true,
                    modelValue: newPage.value,
                    disable: props.disable,
                    dark: isDark(),
                    borderless: true,
                    inputClass: props.inputClass,
                    inputStyle: props.inputStyle,
                    placeholder: inputPlaceholder.value,
                    min: minProp.value,
                    max: maxProp.value,
                    'onUpdate:modelValue': onInputValue,
                    onKeyup,
                    onBlur: updateModel
                  })
                : h(
                    'div',
                    {
                      class: 'q-pagination__middle row justify-center'
                    },
                    contentMiddle
                  ),

              ...contentEnd
            ]
          )
        ]
      )
    }
  }
})
