import { computed, h } from 'vue'

import useQuasar from '../../composables/use-quasar/use-quasar.js'
import useDark, {
  useDarkProps
} from '../../composables/private.use-dark/use-dark.js'

import { createComponent } from '../../utils/private.create/create.js'
import { hSlot } from '../../utils/private.render/render.js'

const separatorValues = ['horizontal', 'vertical', 'cell', 'none']

export default /*#__PURE__*/ createComponent({
  name: 'QMarkupTable',

  props: {
    ...useDarkProps,

    dense: Boolean,
    flat: Boolean,
    bordered: Boolean,
    square: Boolean,
    wrapCells: Boolean,

    separator: {
      type: String,
      default: 'horizontal',
      validator: v => separatorValues.includes(v)
    }
  },

  setup(props, { slots }) {
    const $q = useQuasar()
    const isDark = useDark(props, $q)

    const classes = computed(
      () =>
        'q-markup-table q-table__container q-table__card' +
        ` q-table--${props.separator}-separator` +
        (isDark() ? ' q-table--dark q-table__card--dark q-dark' : '') +
        (props.dense ? ' q-table--dense' : '') +
        (props.flat ? ' q-table--flat' : '') +
        (props.bordered ? ' q-table--bordered' : '') +
        (props.square ? ' q-table--square' : '') +
        (props.wrapCells ? '' : ' q-table--no-wrap')
    )

    return () =>
      h(
        'div',
        {
          class: classes.value,
          // horizontally scrollable region: keyboard users need a way in
          // (WCAG 2.1.1)
          tabindex: 0
        },
        [h('table', { class: 'q-table' }, hSlot(slots.default))]
      )
  }
})
