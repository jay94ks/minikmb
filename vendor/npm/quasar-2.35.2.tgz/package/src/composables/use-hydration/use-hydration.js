import { onMounted, ref } from 'vue'

// using it to manage SSR/SSG rendering with best performance
import { isRuntimeSsrPreHydration } from '../../plugins/platform/Platform.js'

export default function useHydration() {
  const isHydrated = ref(!isRuntimeSsrPreHydration.value)

  if (!isHydrated.value) {
    onMounted(() => {
      isHydrated.value = true
    })
  }

  return { isHydrated }
}
