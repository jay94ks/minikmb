import {
  KeepAlive,
  Transition,
  computed,
  getCurrentInstance,
  h,
  ref,
  watch
} from 'vue'

import TouchSwipe from '../../directives/touch-swipe/TouchSwipe.js'

import useQuasar from '../use-quasar/use-quasar.js'
import useRenderCache from '../../composables/use-render-cache/use-render-cache.js'
import useTimeout from '../../composables/use-timeout/use-timeout.js'

import { hSlot } from '../../utils/private.render/render.js'
import { getNormalizedVNodes } from '../../utils/private.vm/vm.js'

export const usePanelChildProps = {
  name: { required: true },
  disable: Boolean
}

const panelClassProps = { class: 'q-panel scroll' }

const PanelWrapper = {
  setup(_, { slots }) {
    return () =>
      // the ARIA role belongs to the panel component inside
      // (QTabPanel/QStep/QCarouselSlide), not to this wrapper
      h('div', panelClassProps, hSlot(slots.default))
  }
}

export const usePanelProps = {
  modelValue: {
    required: true
  },

  animated: Boolean,
  infinite: Boolean,
  swipeable: Boolean,
  vertical: Boolean,

  transitionPrev: String,
  transitionNext: String,
  transitionDuration: {
    type: [String, Number],
    default: 300
  },

  keepAlive: Boolean,
  keepAliveInclude: [String, Array, RegExp],
  keepAliveExclude: [String, Array, RegExp],
  keepAliveMax: Number
}

export const usePanelEmits = [
  'update:modelValue',
  'beforeTransition',
  'transition'
]

function isValidPanelName(name) {
  return name !== void 0 && name !== null && name !== ''
}

function isPanelVNode(vnode) {
  return (
    vnode.props !== null &&
    vnode.props.slot === void 0 &&
    isValidPanelName(vnode.props.name)
  )
}

export default function usePanel() {
  const { props, emit, proxy } = getCurrentInstance()
  const $q = useQuasar()
  const { getCache } = useRenderCache()
  const { registerTimeout } = useTimeout()

  let panels, forcedPanelTransition

  const panelTransition = ref(null)

  /*
   * Should not be reactive because it's assigned on render
   * and it will trigger a subsequent useless render.
   *
   * Should be an object though, because it is being exported.
   * Otherwise, the current value would be exported and no subsequent
   * updates will be reflected in the exported value.
   */
  const panelIndex = { value: null }

  function onSwipe(evt) {
    const dir = props.vertical ? 'up' : 'left'
    goToPanelByOffset(
      (!props.vertical && $q.lang.rtl ? -1 : 1) *
        (evt.direction === dir ? 1 : -1)
    )
  }

  const panelDirectives = computed(() => [
    [
      TouchSwipe,
      // TouchSwipe only acquires gestures while its value is a function;
      // detaching the directive instead would re-create every panel on a
      // swipeable toggle (#12668)
      props.swipeable ? onSwipe : void 0,
      void 0,
      {
        horizontal: !props.vertical,
        vertical: props.vertical,
        mouse: true
      }
    ]
  ])

  function getTransitionPrev() {
    return (
      props.transitionPrev ||
      `slide-${props.vertical ? 'down' : $q.lang.rtl ? 'left' : 'right'}`
    )
  }

  function getTransitionNext() {
    return (
      props.transitionNext ||
      `slide-${props.vertical ? 'up' : $q.lang.rtl ? 'right' : 'left'}`
    )
  }

  function getContentKey() {
    return typeof props.modelValue === 'string' ||
      typeof props.modelValue === 'number'
      ? props.modelValue
      : String(props.modelValue)
  }

  const keepAliveProps = computed(() => ({
    include: props.keepAliveInclude,
    exclude: props.keepAliveExclude,
    max: props.keepAliveMax
  }))

  const needsUniqueKeepAliveWrapper = computed(
    () => props.keepAliveInclude !== void 0 || props.keepAliveExclude !== void 0
  )

  watch(
    () => props.modelValue,
    (newVal, oldVal) => {
      const index = isValidPanelName(newVal) ? getPanelIndex(newVal) : -1

      if (!forcedPanelTransition) {
        updatePanelTransition(
          index === -1 ? 0 : index < getPanelIndex(oldVal) ? -1 : 1
        )
      }

      if (panelIndex.value !== index) {
        panelIndex.value = index
        emit('beforeTransition', newVal, oldVal)
        registerTimeout(() => {
          emit('transition', newVal, oldVal)
        }, props.transitionDuration)
      }
    }
  )

  function nextPanel() {
    goToPanelByOffset(1)
  }
  function previousPanel() {
    goToPanelByOffset(-1)
  }

  function goToPanel(name) {
    emit('update:modelValue', name)
  }

  function getPanelIndex(name) {
    return panels.findIndex(
      panel =>
        panel.props.name === name &&
        panel.props.disable !== '' &&
        panel.props.disable !== true
    )
  }

  function getEnabledPanels() {
    return panels.filter(
      panel => panel.props.disable !== '' && panel.props.disable !== true
    )
  }

  function updatePanelTransition(direction) {
    const val =
      direction !== 0 && props.animated && panelIndex.value !== -1
        ? 'q-transition--' +
          (direction === -1 ? getTransitionPrev() : getTransitionNext())
        : null

    if (panelTransition.value !== val) {
      panelTransition.value = val
    }
  }

  function goToPanelByOffset(direction, startIndex = panelIndex.value) {
    let index = startIndex + direction

    while (index >= 0 && index < panels.length) {
      const opt = panels[index]

      if (
        opt !== void 0 &&
        opt.props.disable !== '' &&
        opt.props.disable !== true
      ) {
        updatePanelTransition(direction)
        forcedPanelTransition = true
        emit('update:modelValue', opt.props.name)

        // oxlint-disable-next-line no-loop-func
        setTimeout(() => {
          forcedPanelTransition = false
        }, 0)

        return
      }

      index += direction
    }

    if (
      props.infinite &&
      panels.length !== 0 &&
      startIndex !== -1 &&
      startIndex !== panels.length
    ) {
      goToPanelByOffset(direction, direction === -1 ? panels.length : -1)
    }
  }

  function updatePanelIndex() {
    const index = getPanelIndex(props.modelValue)

    if (panelIndex.value !== index) {
      panelIndex.value = index
    }

    return true
  }

  function getPanelContentChild() {
    const panel =
      isValidPanelName(props.modelValue) &&
      updatePanelIndex() &&
      panels[panelIndex.value]

    const contentKey = getContentKey()
    const transitionStyle = `--q-transition-duration: ${props.transitionDuration}ms`

    return props.keepAlive
      ? [
          h(KeepAlive, keepAliveProps.value, [
            h(
              needsUniqueKeepAliveWrapper.value
                ? getCache(contentKey, () => ({
                    ...PanelWrapper,
                    name: contentKey
                  }))
                : PanelWrapper,
              { key: contentKey, style: transitionStyle },
              () => panel
            )
          ])
        ]
      : [
          h(
            'div',
            {
              class: 'q-panel scroll',
              style: transitionStyle,
              key: contentKey
            },
            [panel]
          )
        ]
  }

  function getPanelContent() {
    if (panels.length === 0) return

    return props.animated
      ? [h(Transition, { name: panelTransition.value }, getPanelContentChild)]
      : getPanelContentChild()
  }

  function updatePanelsList(slots) {
    panels = getNormalizedVNodes(hSlot(slots.default, []), isPanelVNode)
    return panels.length
  }

  function getPanels() {
    return panels
  }

  // expose public methods
  Object.assign(proxy, {
    next: nextPanel,
    previous: previousPanel,
    goTo: goToPanel
  })

  return {
    panelIndex,
    panelTransition,
    panelDirectives,

    updatePanelsList,
    updatePanelIndex,

    getPanelContent,
    getEnabledPanels,
    getPanels,

    isValidPanelName,

    keepAliveProps,
    needsUniqueKeepAliveWrapper,

    goToPanelByOffset,
    goToPanel,

    nextPanel,
    previousPanel
  }
}
