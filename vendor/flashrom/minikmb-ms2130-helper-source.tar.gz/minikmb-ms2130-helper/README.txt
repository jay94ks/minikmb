MiniKMB MS2130 helper corresponding source (GPL-2.0-or-later)
flashrom 1.8.0 commit 90b6b4376c7480a223e7bb5642e7116315ac6d09
Changes: finite Windows serial I/O timeouts; separate serprog frontend, capacity gate before writes, preserve tail, full readback compare.
See flashrom/COPYING.rst and source file notices. Run python3 rebuild.py under Linux/WSL with Meson, Ninja, patch and mingw-w64 GCC installed. Compiler versions can change output hashes.
