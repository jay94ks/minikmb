/*
 * This file is part of the flashrom project.
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * SPDX-FileCopyrightText: 2009 Uwe Hermann <uwe@hermann-uwe.de>
 * SPDX-FileCopyrightText: 2009 Carl-Daniel Hailfinger
 * SPDX-FileCopyrightText: 2011-2014 Stefan Tauner
 */

#include "platform/string.h"
#include "flash.h"
#include "log.h"
#include <stdlib.h>

void print_chip_support_status(const struct flashchip *chip)
{
	if (chip->feature_bits & FEATURE_OTP) {
		msg_cdbg("This chip may contain one-time programmable memory. flashrom cannot read\n"
			 "and may never be able to write it, hence it may not be able to completely\n"
			 "clone the contents of this chip (see man page for details).\n");
	}

	if ((chip->tested.erase == NA) && (chip->tested.write == NA)) {
		msg_cdbg("This chip's main memory can not be erased/written by design.\n");
	}

	if ((chip->tested.probe == BAD) || (chip->tested.probe == NT) ||
	    (chip->tested.read == BAD)  || (chip->tested.read == NT) ||
	    (chip->tested.erase == BAD) || (chip->tested.erase == NT) ||
	    (chip->tested.write == BAD) || (chip->tested.write == NT) ||
	    (chip->tested.wp == BAD) || (chip->tested.wp == NT)){
		msg_cinfo("===\n");
		if ((chip->tested.probe == BAD) ||
		    (chip->tested.read == BAD) ||
		    (chip->tested.erase == BAD) ||
		    (chip->tested.write == BAD) ||
		    (chip->tested.wp == BAD)) {
			msg_cinfo("This flash part has status NOT WORKING for operations:");
			if (chip->tested.probe == BAD)
				msg_cinfo(" PROBE");
			if (chip->tested.read == BAD)
				msg_cinfo(" READ");
			if (chip->tested.erase == BAD)
				msg_cinfo(" ERASE");
			if (chip->tested.write == BAD)
				msg_cinfo(" WRITE");
			if (chip->tested.wp == BAD)
				msg_cinfo(" WP");
			msg_cinfo("\n");
		}
		if ((chip->tested.probe == NT) ||
		    (chip->tested.read == NT) ||
		    (chip->tested.erase == NT) ||
		    (chip->tested.write == NT) ||
		    (chip->tested.wp == NT)) {
			msg_cinfo("This flash part has status UNTESTED for operations:");
			if (chip->tested.probe == NT)
				msg_cinfo(" PROBE");
			if (chip->tested.read == NT)
				msg_cinfo(" READ");
			if (chip->tested.erase == NT)
				msg_cinfo(" ERASE");
			if (chip->tested.write == NT)
				msg_cinfo(" WRITE");
			if (chip->tested.wp == NT)
				msg_cinfo(" WP");
			msg_cinfo("\n");
		}
		msg_cinfo("The test status of this chip may have been updated in the latest development\n"
			  "version of flashrom. If you are running the latest development version,\n"
			  "please email a report to flashrom@flashrom.org if any of the above operations\n"
			  "work correctly for you with this flash chip. Please include the flashrom log\n"
			  "file for all operations you tested (see the man page for details), and mention\n"
			  "which mainboard or programmer you tested in the subject line.\n"
			  "You can also try to follow the instructions here:\n"
			  "https://www.flashrom.org/contrib_howtos/how_to_mark_chip_tested.html\n"
			  "Thanks for your help!\n");
	}
}
