/*
 * This file is part of the flashrom project.
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * SPDX-FileCopyrightText: 2020 The Chromium OS Authors
 *
 * This file provides a platform independent way to access I2C devices.
 */

#include "platform/i2c.h"

#include "log.h"
#include <errno.h>
#include <stdio.h>
#include "platform/string.h"
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>


/* Null characters are placeholders for bus number digits */
#define I2C_DEV_PREFIX	"/dev/i2c-\0\0\0"
#define I2C_MAX_BUS	255


int i2c_close(int fd)
{
	return fd == -1 ? 0 : close(fd);
}

int i2c_open_path(const char *path, uint16_t addr, int force)
{
	int fd = open(path, O_RDWR);
	if (fd < 0) {
		msg_perr("Unable to open I2C device %s: %s.\n", path, strerror(errno));
		return fd;
	}

	int request = force ? I2C_SLAVE_FORCE : I2C_SLAVE;
	int ret = ioctl(fd, request, addr);
	if (ret < 0) {
		msg_perr("Unable to set I2C slave address to 0x%02x: %s.\n", addr, strerror(errno));
		i2c_close(fd);
		return ret;
	}

	return fd;
}

int i2c_open(int bus, uint16_t addr, int force)
{
	char dev[sizeof(I2C_DEV_PREFIX)] = {0};

	int ret = -1;

	if (bus < 0 || bus > I2C_MAX_BUS) {
		msg_perr("Invalid I2C bus %d.\n", bus);
		return ret;
	}

	ret = snprintf(dev, sizeof(dev), "%s%d", I2C_DEV_PREFIX, bus);
	if (ret < 0) {
		msg_perr("Unable to join bus number to device name: %s.\n", strerror(errno));
		return ret;
	}

	return i2c_open_path(dev, addr, force);
}

int i2c_read(int fd, uint16_t addr, i2c_buffer_t *buf)
{
	if (buf->len == 0)
		return 0;

	int ret = ioctl(fd, I2C_SLAVE, addr);
	if (ret < 0) {
		msg_perr("Unable to set I2C slave address to 0x%02x: %s.\n", addr, strerror(errno));
		return ret;
	}

	return read(fd, buf->buf, buf->len);
}

int i2c_write(int fd, uint16_t addr, const i2c_buffer_t *buf)
{
	if (buf->len == 0)
		return 0;

	int ret = ioctl(fd, I2C_SLAVE, addr);
	if (ret < 0) {
		msg_perr("Unable to set I2C slave address to 0x%02x: %s.\n", addr, strerror(errno));
		return ret;
	}

	return write(fd, buf->buf, buf->len);
}
