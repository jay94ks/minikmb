/*
 * This file is part of the flashrom project.
 *
 * SPDX-License-Identifier: GPL-2.0-only
 * SPDX-FileCopyrightText: 2021 Google LLC
 *
 * This file contains tests for operations on flash chip.
 *
 * Two flash chip test variants are used:
 *
 * 1) Mock chip state backed by `g_chip_state`.
 * Example of test: erase_chip_test_success.
 *
 * 2) Mock chip operations backed by `dummyflasher` emulation.
 * Dummyflasher controls chip state and emulates read/write/erase.
 * `g_chip_state` is NOT used for this type of tests.
 * Example of test: erase_chip_with_dummyflasher_test_success.
 */

#include <include/test.h>
#include <stdio.h>
#include <stdlib.h>
#include "platform/string.h"

#include "tests.h"
#include "chipdrivers.h"
#include "flash.h"
#include "io_mock.h"
#include "libflashrom.h"
#include "programmer.h"

#define MOCK_CHIP_SIZE (8*MiB)
#define MOCK_CHIP_CONTENT 0xCC /* 0x00 is a zeroed heap and 0xFF is an erased chip. */

static struct {
	uint8_t buf[MOCK_CHIP_SIZE]; /* buffer of total size of chip, to emulate a chip */
	/* Die fields can be ignored for single-die chip. */
	unsigned int current_die;
	unsigned int die_selected[8]; /* how many times die select was called for the die #index */
} g_chip_state = {
	.buf = { 0 },
	.current_die = 0,
	.die_selected = { 0 },
};

struct progress_user_data {
	/* % of progress last reported for each operation, to be asserted in the progress callback. */
	size_t last_seen[FLASHROM_PROGRESS_NR];
};

static int read_chip(struct flashctx *flash, uint8_t *buf, unsigned int start, unsigned int len)
{
	printf("Read chip called with start=0x%x, len=0x%x\n", start, len);

	assert_true(start + len <= MOCK_CHIP_SIZE);

	memcpy(buf, &g_chip_state.buf[start], len);
	return 0;
}

static int write_chip(struct flashctx *flash, const uint8_t *buf, unsigned int start, unsigned int len)
{
	printf("Write chip called with start=0x%x, len=0x%x\n", start, len);

	assert_true(start + len <= MOCK_CHIP_SIZE);

	memcpy(&g_chip_state.buf[start], buf, len);
	return 0;
}

static int block_erase_chip(struct flashctx *flash, unsigned int blockaddr, unsigned int blocklen)
{
	printf("Block erase called with blockaddr=0x%x, blocklen=0x%x\n", blockaddr, blocklen);

	assert_true(blockaddr + blocklen <= MOCK_CHIP_SIZE);

	memset(&g_chip_state.buf[blockaddr], 0xff, blocklen);
	return 0;
}

static int select_die(struct flashctx* flash, unsigned int die_num)
{
	printf("Die select called for die #%d.\n", die_num);

	assert_true(die_num < flash->chip->total_size / flash->chip->die_size);

	g_chip_state.current_die = die_num;
	g_chip_state.die_selected[die_num]++;
	return 0;
}

static void progress_callback(enum flashrom_progress_stage stage, size_t current, size_t total, void* user_data) {
	struct progress_user_data *progress_user_data = user_data;

	if (current == 0) {
		printf("Progress started for stage %d, initial callback call\n", stage);
	} else {
		/* Progress cannot go backwards. */
		assert_true(current >= progress_user_data->last_seen[stage]);
	}

	if (current >= total - 1)
		printf("Progress almost complete for stage %d, current %zu, total %zu\n", stage, current, total);

	progress_user_data->last_seen[stage] = current;
}

static void setup_chip(struct flashrom_flashctx *flashctx,
		struct flashchip *chip, const char *programmer_param, const struct io_mock *io)
{
	io_mock_register(io);

	flashctx->chip = chip;

	memset(g_chip_state.buf, MOCK_CHIP_CONTENT, sizeof(g_chip_state.buf));
	g_chip_state.current_die = 0;
	memset(g_chip_state.die_selected, 0, sizeof(g_chip_state.die_selected));

	printf("Creating layout with one included region... ");
	assert_int_equal(0, flashrom_layout_new(&flashctx->default_layout));
	/* One region which covers total size of chip. */
	assert_int_equal(0, flashrom_layout_add_region(flashctx->default_layout, 0, chip->total_size * KiB - 1, "region"));
	assert_int_equal(0, flashrom_layout_include_region(flashctx->default_layout, "region"));

	printf("done\n");

	/*
	 * We need some programmer (any), and dummy is a very good one,
	 * because it doesn't need any mocking. So no extra complexity
	 * from a programmer side, and test can focus on working with the chip.
	 */
	printf("Dummyflasher initialising with param=\"%s\"... ", programmer_param);
	assert_int_equal(0, programmer_init(&programmer_dummy, programmer_param));
	/* Assignment below normally happens while probing, but this test is not probing. */
	flashctx->mst = &registered_masters[0];
	printf("done\n");
}

static void teardown(struct flashrom_flashctx *flashctx)
{
	printf("Dummyflasher shutdown... ");
	assert_int_equal(0, programmer_shutdown());
	printf("done\n");

	printf("Releasing layout... ");
	flashrom_layout_release(flashctx->default_layout);
	printf("done\n");

	io_mock_register(NULL);
}

static const struct flashchip chip_8MiB = {
	.vendor		= "aklm",
	.total_size	= MOCK_CHIP_SIZE / KiB,
	.tested		= TEST_OK_PREW,
	.read		= TEST_READ_INJECTOR,
	.write		= TEST_WRITE_INJECTOR,
	.page_size	= 256,
	.block_erasers	=
	{{
		 /* All blocks within total size of the chip. */
		.eraseblocks = { {2 * MiB, 4} },
		.block_erase = TEST_ERASE_INJECTOR_1,
	 }},
};

/* Chip expected to be processed with dummyflasher, so using real op functions. */
static const struct flashchip chip_no_erase = {
	.vendor		= "aklm&dummyflasher",
	.total_size	= 16 * 1024,
	.tested		= TEST_OK_PREW,
	.read		= SPI_CHIP_READ,
	.write		= SPI_CHIP_WRITE256,
	.page_size	= 256,
	.feature_bits   = FEATURE_NO_ERASE | FEATURE_ERASED_ZERO,
	.block_erasers  =
	{
		{
			.eraseblocks = { {16 * 1024 * 1024, 1} },
			/* Special erase fn for chips without erase capability. */
			.block_erase = SPI_BLOCK_ERASE_EMULATION,
		}
	},
};

/* Chip with tested status known BAD for all operations, expected to fail chip_safety_check. */
static const struct flashchip chip_bad = {
	.vendor		= "aklm",
	.total_size	= MOCK_CHIP_SIZE / KiB,
	.tested		= TEST_BAD_PREWB,
	.read		= TEST_READ_INJECTOR,
	.write		= TEST_WRITE_INJECTOR,
	.page_size	= 256,
	.block_erasers	=
	{{
		 /* All blocks within total size of the chip. */
		.eraseblocks = { {2 * MiB, 4} },
		.block_erase = TEST_ERASE_INJECTOR_1,
	 }},
};

/* Setup the struct for W25Q128.V, all values come from flashchips.c */
static const struct flashchip chip_dual_die_c2 = {
	.vendor		= "aklm&dummyflasher",
	.total_size	= 16 * 1024,
	.die_size	= 8 * 1024,
	.page_size	= 256,
	.feature_bits   = FEATURE_WRSR_WREN | FEATURE_STATUS_PER_DIE,
	.tested		= TEST_OK_PREW,
	.read		= SPI_CHIP_READ,
	.write		= SPI_CHIP_WRITE256,
	.die_select	= TEST_DIESELECT_INJECTOR,
	.block_erasers  =
	{
		/* The goal is to test select die feature, which is used for
		 * chip erase ops 60h and C7h. No other ops are needed for this mock. */
		{
			.eraseblocks = { {16 * 1024 * 1024, 1} },
			.block_erase = SPI_BLOCK_ERASE_60,
		}, {
			.eraseblocks = { {16 * 1024 * 1024, 1} },
			.block_erase = SPI_BLOCK_ERASE_C7,
		}
	},
};

/* Setup the struct for W25Q128.V, all values come from flashchips.c */
static const struct flashchip chip_W25Q128_V = {
	.vendor		= "aklm&dummyflasher",
	.total_size	= 16 * 1024,
	.tested		= TEST_OK_PREW,
	.read		= SPI_CHIP_READ,
	.write		= SPI_CHIP_WRITE256,
	.page_size	= 256,
	.block_erasers  =
	{
		{
			.eraseblocks = { {4 * 1024, 4096} },
			.block_erase = SPI_BLOCK_ERASE_20,
		}, {
			.eraseblocks = { {32 * 1024, 512} },
			.block_erase = SPI_BLOCK_ERASE_52,
		}, {
			.eraseblocks = { {64 * 1024, 256} },
			.block_erase = SPI_BLOCK_ERASE_D8,
		}, {
			.eraseblocks = { {16 * 1024 * 1024, 1} },
			.block_erase = SPI_BLOCK_ERASE_60,
		}, {
			.eraseblocks = { {16 * 1024 * 1024, 1} },
			.block_erase = SPI_BLOCK_ERASE_C7,
		}
	},
};

void erase_chip_test_success(void **state)
{
	(void) state; /* unused */

	g_test_write_injector = write_chip;
	g_test_read_injector = read_chip;
	g_test_erase_injector[0] = block_erase_chip;
	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_8MiB;
	const char *param = ""; /* Default values for all params. */

	setup_chip(&flashctx, &mock_chip, param, NULL);

	printf("Erase chip operation started.\n");
	assert_int_equal(0, flashrom_flash_erase(&flashctx));
	printf("Erase chip operation done.\n");

	teardown(&flashctx);
}

void erase_chip_with_progress(void **state)
{
	(void) state; /* unused */

	g_test_write_injector = write_chip;
	g_test_read_injector = read_chip;
	g_test_erase_injector[0] = block_erase_chip;
	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_8MiB;
	const char *param = ""; /* Default values for all params. */

	setup_chip(&flashctx, &mock_chip, param, NULL);

	struct progress_user_data progress_user_data = {0};
	flashrom_set_progress_callback_v2(&flashctx, progress_callback, &progress_user_data);

	printf("Erase chip operation started.\n");
	assert_int_equal(0, flashrom_flash_erase(&flashctx));
	printf("Erase chip operation done.\n");

	teardown(&flashctx);
}

void erase_chip_with_dummyflasher_test_success(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_W25Q128_V;
	/*
	 * Dummyflasher is capable to emulate W25Q128.V, so we ask it to do this.
	 * Nothing to mock, dummy is taking care of this already.
	 */
	const char *param_dup = "bus=spi,emulate=W25Q128FV";

	setup_chip(&flashctx, &mock_chip, param_dup, NULL);

	printf("Erase chip operation started.\n");
	assert_int_equal(0, flashrom_flash_erase(&flashctx));
	printf("Erase chip operation done.\n");

	teardown(&flashctx);
}

void erase_chip_dual_die_c2(void **state)
{
	(void) state; /* unused */

	g_test_dieselect_injector = select_die;
	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_dual_die_c2;
	/*
	 * Tricking the dummyflasher by asking to emulate W25Q128FV but giving to it
	 * mock chip with FEATURE_STATUS_PER_DIE.
	 * As long as chip size is the same, this is fine.
	 */
	const char *param_dup = "bus=spi,emulate=W25Q128FV";

	setup_chip(&flashctx, &mock_chip, param_dup, NULL);

	printf("Erase chip operation started.\n");
	assert_int_equal(0, flashrom_flash_erase(&flashctx));
	printf("Erase chip operation done.\n");

	/* Expected to always switch to die 0 after polling completes. */
	assert_true(g_chip_state.current_die == 0);
	printf("Active die switched to #%d after erase\n", g_chip_state.current_die);
	/* Expected to poll each die at least once */
	const unsigned int num_dies = flashctx.chip->total_size / flashctx.chip->die_size;
	for (unsigned int i = 0; i < num_dies; i++)
		assert_true(g_chip_state.die_selected[i] > 0);
	printf("Each die was polled at least once.\n");

	teardown(&flashctx);
}

void read_chip_test_success(void **state)
{
	(void) state; /* unused */

	g_test_write_injector = write_chip;
	g_test_read_injector = read_chip;
	g_test_erase_injector[0] = block_erase_chip;
	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_8MiB;
	const char *param = ""; /* Default values for all params. */

	setup_chip(&flashctx, &mock_chip, param, NULL);

	const char *const filename = "read_chip.test";
	unsigned long size = mock_chip.total_size * 1024;
	unsigned char *buf = calloc(size, sizeof(unsigned char));
	assert_non_null(buf);

	printf("Read chip operation started.\n");
	assert_int_equal(0, flashrom_image_read(&flashctx, buf, size));
	assert_int_equal(0, write_buf_to_file(buf, size, filename));
	printf("Read chip operation done.\n");

	teardown(&flashctx);

	free(buf);
}

void read_chip_with_progress(void **state)
{
	(void) state; /* unused */

	g_test_write_injector = write_chip;
	g_test_read_injector = read_chip;
	g_test_erase_injector[0] = block_erase_chip;
	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_8MiB;
	const char *param = ""; /* Default values for all params. */

	setup_chip(&flashctx, &mock_chip, param, NULL);

	struct progress_user_data progress_user_data = {0};
	flashrom_set_progress_callback_v2(&flashctx, progress_callback, &progress_user_data);

	const char *const filename = "read_chip.test";
	unsigned long size = mock_chip.total_size * 1024;
	unsigned char *buf = calloc(size, sizeof(unsigned char));
	assert_non_null(buf);

	printf("Read chip operation started.\n");
	assert_int_equal(0, flashrom_image_read(&flashctx, buf, size));
	assert_int_equal(0, write_buf_to_file(buf, size, filename));
	printf("Read chip operation done.\n");

	teardown(&flashctx);

	free(buf);
}

void read_chip_with_dummyflasher_test_success(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_W25Q128_V;
	/*
	 * Dummyflasher is capable to emulate W25Q128.V, so we ask it to do this.
	 * Nothing to mock, dummy is taking care of this already.
	 */
	const char *param_dup = "bus=spi,emulate=W25Q128FV";

	setup_chip(&flashctx, &mock_chip, param_dup, NULL);

	const char *const filename = "read_chip.test";
	unsigned long size = mock_chip.total_size * 1024;
	unsigned char *buf = calloc(size, sizeof(unsigned char));
	assert_non_null(buf);

	printf("Read chip operation started.\n");
	assert_int_equal(0, flashrom_image_read(&flashctx, buf, size));
	assert_int_equal(0, write_buf_to_file(buf, size, filename));
	printf("Read chip operation done.\n");

	teardown(&flashctx);

	free(buf);
}

void write_chip_test_success(void **state)
{
	(void) state; /* unused */

	g_test_write_injector = write_chip;
	g_test_read_injector = read_chip;
	g_test_erase_injector[0] = block_erase_chip;
	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_8MiB;
	const char *param = ""; /* Default values for all params. */

	setup_chip(&flashctx, &mock_chip, param, NULL);

	/*
	 * Providing filename "-" means content is taken from standard input.
	 * This doesn't change much because all file operations are mocked.
	 * However filename "-" makes a difference for
	 * flashrom.c#read_buf_from_file and allows to avoid mocking
	 * image_stat.st_size.
	 *
	 * Now this does mean test covers successful path only, but this test
	 * is designed to cover only successful write operation anyway.
	 *
	 * To cover error path of image_stat.st_size != flash size, filename
	 * needs to be provided and image_stat.st_size needs to be mocked.
	 */
	const char *const filename = "-";
	unsigned long size = mock_chip.total_size * 1024;
	uint8_t *const newcontents = malloc(size);
	assert_non_null(newcontents);

	printf("Write chip operation started.\n");
	assert_int_equal(0, read_buf_from_file(newcontents, size, filename));
	assert_int_equal(0, flashrom_image_write(&flashctx, newcontents, size, NULL));
	printf("Write chip operation done.\n");

	teardown(&flashctx);

	free(newcontents);
}

void write_chip_with_progress(void **state)
{
	(void) state; /* unused */

	g_test_write_injector = write_chip;
	g_test_read_injector = read_chip;
	g_test_erase_injector[0] = block_erase_chip;
	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_8MiB;
	const char *param = ""; /* Default values for all params. */

	setup_chip(&flashctx, &mock_chip, param, NULL);

	struct progress_user_data progress_user_data = {0};
	flashrom_set_progress_callback_v2(&flashctx, progress_callback, &progress_user_data);

	const char *const filename = "-";
	unsigned long size = mock_chip.total_size * 1024;
	uint8_t *const newcontents = malloc(size);
	assert_non_null(newcontents);

	printf("Write chip operation started.\n");
	assert_int_equal(0, read_buf_from_file(newcontents, size, filename));
	assert_int_equal(0, flashrom_image_write(&flashctx, newcontents, size, NULL));
	printf("Write chip operation done.\n");

	teardown(&flashctx);

	free(newcontents);
}

void write_chip_with_dummyflasher_test_success(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_W25Q128_V;
	/*
	 * Dummyflasher is capable to emulate W25Q128.V, so we ask it to do this.
	 * Nothing to mock, dummy is taking care of this already.
	 */
	const char *param_dup = "bus=spi,emulate=W25Q128FV";

	setup_chip(&flashctx, &mock_chip, param_dup, NULL);

	/* See comment in write_chip_test_success */
	const char *const filename = "-";
	unsigned long size = mock_chip.total_size * 1024;
	uint8_t *const newcontents = malloc(size);
	assert_non_null(newcontents);

	printf("Write chip operation started.\n");
	assert_int_equal(0, read_buf_from_file(newcontents, size, filename));
	assert_int_equal(0, flashrom_image_write(&flashctx, newcontents, size, NULL));
	printf("Write chip operation done.\n");

	teardown(&flashctx);

	free(newcontents);
}

void write_chip_feature_no_erase(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = { 0 };

	/*
	 * Tricking the dummyflasher by asking to emulate W25Q128FV but giving to it
	 * mock chip with FEATURE_NO_ERASE.
	 * As long as chip size is the same, this is fine.
	 */
	struct flashchip mock_chip = chip_no_erase;
	const char *param_dup = "bus=spi,emulate=W25Q128FV";

	setup_chip(&flashctx, &mock_chip, param_dup, NULL);

	/* See comment in write_chip_test_success */
	const char *const filename = "-";
	unsigned long size = mock_chip.total_size * 1024;
	uint8_t *const newcontents = malloc(size);
	assert_non_null(newcontents);

	printf("Write chip operation started.\n");
	assert_int_equal(0, read_buf_from_file(newcontents, size, filename));
	assert_int_equal(0, flashrom_image_write(&flashctx, newcontents, size, NULL));
	assert_int_equal(0, flashrom_image_verify(&flashctx, newcontents, size));
	printf("Write chip operation done.\n");

	teardown(&flashctx);

	free(newcontents);
}

void write_chip_feature_no_erase_with_progress(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = { 0 };

	/*
	 * Tricking the dummyflasher by asking to emulate W25Q128FV but giving to it
	 * mock chip with FEATURE_NO_ERASE.
	 * As long as chip size is the same, this is fine.
	 */
	struct flashchip mock_chip = chip_no_erase;
	const char *param_dup = "bus=spi,emulate=W25Q128FV";

	setup_chip(&flashctx, &mock_chip, param_dup, NULL);

	/* See comment in write_chip_test_success */
	const char *const filename = "-";
	unsigned long size = mock_chip.total_size * 1024;
	uint8_t *const newcontents = malloc(size);
	assert_non_null(newcontents);

	struct progress_user_data progress_user_data = {0};
	flashrom_set_progress_callback_v2(&flashctx, progress_callback, &progress_user_data);

	printf("Write chip operation started.\n");
	assert_int_equal(0, read_buf_from_file(newcontents, size, filename));
	assert_int_equal(0, flashrom_image_write(&flashctx, newcontents, size, NULL));
	assert_int_equal(0, flashrom_image_verify(&flashctx, newcontents, size));
	printf("Write chip operation done.\n");

	teardown(&flashctx);

	free(newcontents);
}


void write_nonaligned_region_with_dummyflasher_test_success(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_W25Q128_V;
	const uint32_t mock_chip_size = mock_chip.total_size * KiB;
	/*
	 * Dummyflasher is capable to emulate W25Q128.V, so we ask it to do this.
	 * Nothing to mock, dummy is taking care of this already.
	 */
	const char *param_dup = "bus=spi,emulate=W25Q128FV";

	/* FIXME: MOCK_CHIP_CONTENT is buggy within setup_chip, it should also
	 * not be either 0x00 or 0xFF as those are specific values related to
	 * either a erased chip or zero'ed heap thus ambigous.
	 */
#define MOCK_CHIP_SUBREGION_CONTENTS 0xCC
	/**
	 * Step 0 - Prepare newcontents as contiguous sample data bytes as follows:
	 * {MOCK_CHIP_SUBREGION_CONTENTS, [..]}.
	 */
	uint8_t *newcontents = calloc(1, mock_chip_size);
	assert_non_null(newcontents);
	memset(newcontents, MOCK_CHIP_SUBREGION_CONTENTS, mock_chip_size);

	setup_chip(&flashctx, &mock_chip, param_dup, NULL);
	/* Expect to verify only the non-aligned write operation within the region. */
	flashrom_flag_set(&flashctx, FLASHROM_FLAG_VERIFY_AFTER_WRITE, true);
	flashrom_flag_set(&flashctx, FLASHROM_FLAG_VERIFY_WHOLE_CHIP, false);

	/**
	 * Prepare mock chip content and release setup_chip() layout for our
	 * custom ones.
	 */
	assert_int_equal(0, flashrom_image_write(&flashctx, newcontents, mock_chip_size, NULL));
	flashrom_layout_release(flashctx.default_layout);

	/**
	 * Create region smaller than erase granularity of chip.
	 */
	printf("Creating custom region layout... ");
	assert_int_equal(0, flashrom_layout_new(&flashctx.default_layout));
	printf("Adding and including region0... ");
	assert_int_equal(0, flashrom_layout_add_region(flashctx.default_layout, 0, (1 * KiB), "region0"));
	assert_int_equal(0, flashrom_layout_include_region(flashctx.default_layout, "region0"));
	printf("Subregion layout configuration done.\n");

	/**
	 * Step 1 - Modify newcontents as non-contiguous sample data bytes as follows:
	 * 0xAA 0xAA {MOCK_CHIP_SUBREGION_CONTENTS}, [..]}.
	 */
	printf("Subregion chip write op..\n");
	memset(newcontents, 0xAA, 2);
	assert_int_equal(0, flashrom_image_write(&flashctx, newcontents, mock_chip_size, NULL));
	printf("Subregion chip write op done.\n");

	flashrom_layout_release(flashctx.default_layout);
	assert_int_equal(0, flashrom_layout_new(&flashctx.default_layout));
	assert_int_equal(0, flashrom_layout_add_region(flashctx.default_layout, 0, mock_chip_size - 1, "entire"));
	assert_int_equal(0, flashrom_layout_include_region(flashctx.default_layout, "entire"));

	/**
	 * Expect a verification pass that the previous content within the region, however
	 * outside the region write length, is untouched.
	 */
	printf("Entire chip verify op..\n");
	assert_int_equal(0, flashrom_image_verify(&flashctx, newcontents, mock_chip_size));
	printf("Entire chip verify op done.\n");

	teardown(&flashctx);
	free(newcontents);
}

static size_t verify_chip_fread(void *state, void *buf, size_t size, size_t len, FILE *fp)
{
	/*
	 * Verify operation compares contents of the file vs contents on the chip.
	 * To emulate successful verification we emulate file contents to be the
	 * same as what is on the chip.
	 */
	memset(buf, MOCK_CHIP_CONTENT, len);
	return len;
}

void verify_chip_test_success(void **state)
{
	(void) state; /* unused */

	const struct io_mock verify_chip_io = {
		.iom_fread = verify_chip_fread,
	};

	g_test_write_injector = write_chip;
	g_test_read_injector = read_chip;
	g_test_erase_injector[0] = block_erase_chip;
	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_8MiB;
	const char *param = ""; /* Default values for all params. */

	setup_chip(&flashctx, &mock_chip, param, &verify_chip_io);

	/* See comment in write_chip_test_success */
	const char *const filename = "-";
	unsigned long size = mock_chip.total_size * 1024;
	uint8_t *const newcontents = malloc(size);
	assert_non_null(newcontents);

	printf("Verify chip operation started.\n");
	assert_int_equal(0, read_buf_from_file(newcontents, size, filename));
	assert_int_equal(0, flashrom_image_verify(&flashctx, newcontents, size));
	printf("Verify chip operation done.\n");

	teardown(&flashctx);

	free(newcontents);
}

void verify_chip_with_dummyflasher_test_success(void **state)
{
	(void) state; /* unused */

	const struct io_mock verify_chip_io = {
		.iom_fread = verify_chip_fread,
	};

	struct flashrom_flashctx flashctx = { 0 };
	struct flashchip mock_chip = chip_W25Q128_V;
	/*
	 * Dummyflasher is capable to emulate W25Q128.V, so we ask it to do this.
	 * Nothing to mock, dummy is taking care of this already.
	 */
	const char *param_dup = "bus=spi,emulate=W25Q128FV";

	setup_chip(&flashctx, &mock_chip, param_dup, &verify_chip_io);

	/* See comment in write_chip_test_success */
	const char *const filename = "-";
	unsigned long size = mock_chip.total_size * 1024;
	uint8_t *const newcontents = malloc(size);
	assert_non_null(newcontents);

	/*
	 * Dummyflasher controls chip state and fully emulates reads and writes,
	 * so to set up initial chip state we need to write on chip. Write
	 * operation takes content from file and writes on chip. File content is
	 * emulated in verify_chip_fread mock.
	 */

	printf("Write chip operation started.\n");
	assert_int_equal(0, read_buf_from_file(newcontents, size, filename));
	assert_int_equal(0, flashrom_image_write(&flashctx, newcontents, size, NULL));
	printf("Write chip operation done.\n");

	printf("Verify chip operation started.\n");
	assert_int_equal(0, flashrom_image_verify(&flashctx, newcontents, size));
	printf("Verify chip operation done.\n");

	teardown(&flashctx);

	free(newcontents);
}

static void setup_bad_chip(struct flashrom_flashctx *flashctx)
{
	/* This test injectors are not expected to be called, because the
	 * chip has known bad test status and chip_safety_check should fail
	 * before any operation has started. */
	g_test_write_injector = NULL;
	g_test_read_injector = NULL;
	g_test_erase_injector[0] = NULL;

	struct flashchip mock_chip = chip_bad;
	const char *param = ""; /* Default values for all params. */

	setup_chip(flashctx, &mock_chip, param, NULL);
}

void erase_chip_bad_status_test(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = {0};
	setup_bad_chip(&flashctx);

	printf("flashrom_flash_erase called: ");
	assert_int_equal(ERROR_FLASHROM_PREPARE_FLASH_ACCESS, flashrom_flash_erase(&flashctx));
	printf("failed as expected.\n");

	teardown(&flashctx);
}

void read_chip_bad_status_test(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = {0};
	setup_bad_chip(&flashctx);

	unsigned long size = chip_bad.total_size * 1024;
	unsigned char *buf = calloc(size, sizeof(unsigned char));
	assert_non_null(buf);

	printf("flashrom_image_read called: ");
	assert_int_equal(ERROR_FLASHROM_PREPARE_FLASH_ACCESS,
			flashrom_image_read(&flashctx, buf, size));
	printf("failed as expected.\n");

	teardown(&flashctx);

	free(buf);
}

void write_chip_bad_status_test(void **state)
{
	(void) state; /* unused */

	struct flashrom_flashctx flashctx = {0};
	setup_bad_chip(&flashctx);

	unsigned long size = chip_bad.total_size * 1024;
	uint8_t *const newcontents = malloc(size);
	assert_non_null(newcontents);

	printf("flashrom_image_write called: ");
	assert_int_equal(ERROR_FLASHROM_PREPARE_FLASH_ACCESS,
			flashrom_image_write(&flashctx, newcontents, size, NULL));
	printf("failed as expected.\n");

	teardown(&flashctx);

	free(newcontents);
}
