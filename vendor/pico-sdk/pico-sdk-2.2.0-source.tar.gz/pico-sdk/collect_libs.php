<?php

function collects($path) {
    if (!($path = realpath($path))) {
        return [];
    }

    $subs = glob("$path/*", GLOB_ONLYDIR);
    $ret = [];

    while (count ($subs) > 0) {
        if (!is_dir($sub = array_shift($subs))) {
            continue;
        }

        if (is_dir("$sub/include")) {
            array_push($ret, $sub);
        }

        $all = collects($sub);
        $subs = array_merge($subs, $all);
    }

    return $ret;
}

// --
$paths = collects(__DIR__);
$this_path = str_replace("\\", "/", realpath(__DIR__));

$paths = array_map(function ($x) use($this_path) {
    $all = str_replace("\\", "/", realpath("$x/include"));
    $rel_path = ltrim(substr($all, strlen($this_path)), '/');
    //
    return '${env:PICO_SDK_PATH}/' . $rel_path;
}, $paths);

$json = json_encode($paths, 
    JSON_UNESCAPED_SLASHES | 
    JSON_UNESCAPED_UNICODE |
    JSON_PRETTY_PRINT);

print_r($paths);
file_put_contents(__DIR__ . "/libs_all.json", $json);